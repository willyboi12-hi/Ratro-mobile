#!/usr/bin/env python3
"""
Translates Natro Macro's collect routes (paths/gtc-*.ahk) into Java, for trips from the hive.

Handled:
  - if (MoveMethod = "walk") / else: the walk branch is kept, the cannon branch is dropped
  - switch HiveSlot: resolved for each hive slot 1..6
  - if (HiveBees > N): two variants, chosen at run time from the hive's bee count
  - nm_Walk(n, keys...) and Walk(n) with held keys, Sleep / HyperSleep
  - Jump([n, keys...], ...): the walking part only (the jump itself is skipped)
  - RotLeft / RotRight n: camera turns, kept as steps
Skipped (counted and printed):
  - jump presses (space), interact (E) and shift presses: the saved destination taps take their place
  - the hive walk from the ramp (we are already there)
Refused (the route is left out):
  - nm_gotocannon and anything else this script does not understand

Writes:
  <java dir>/TripRoutes.java            translated routes
  <test dir>/TripExpectations.java      walk counts and tile totals from a plain line scan of the same branch

Usage: python3 gen_trips.py <Natro paths folder> <java package folder> <unit test package folder>
Natro is GPL v3; the translated data is derived from it.
"""
import glob
import os
import re
import sys
from collections import Counter

KEYS = {"FwdKey": (0, -1), "BackKey": (0, 1), "LeftKey": (-1, 0), "RightKey": (1, 0)}
KEY_EVENT = re.compile(r'(FwdKey|BackKey|LeftKey|RightKey)\s*"?\s*(down|up)', re.I)
ROT = re.compile(r'Rot(Left|Right)\s*"?\s*(\d+)?', re.I)
NAME = {
    "antpass": "Ant pass", "extrememm": "Extreme mm", "honeydis": "Honey dispenser",
    "stockings": "Stockings", "wreath": "Wreath", "blender": "Blender", "blueberrydis": "Blueberry dispenser",
    "candles": "Candles", "clock": "Clock", "coconutdis": "Coconut dispenser", "feast": "Feast",
    "gingerbread": "Gingerbread", "gluedis": "Glue dispenser", "honeylb": "Honey LB",
    "honeystorm": "Honey storm", "lidart": "Lid art", "megamm": "Mega mm", "nightmm": "Night mm",
    "normalmm": "Normal mm", "robopass": "Robo pass", "samovar": "Samovar", "snowmachine": "Snow machine",
    "stickerPrinter": "Sticker printer", "stickerstack": "Sticker stack", "strawberrydis": "Strawberry dispenser",
    "treatdis": "Treat dispenser", "wintermm": "Winter mm", "WindShrine": "Wind shrine",
}


class Unsupported(Exception):
    pass


def clean(text):
    return text.replace("\ufeff", "").replace("\r", "")


def matching(text, open_idx):
    depth = 0
    for j in range(open_idx, len(text)):
        if text[j] == "{":
            depth += 1
        elif text[j] == "}":
            depth -= 1
            if depth == 0:
                return j
    raise Unsupported("unbalanced braces")


def strip_jump_def(text):
    """Removes the Jump(movements*) helper definition. Its calls are translated separately."""
    m = re.search(r"Jump\(movements\*\)\s*\{", text)
    if not m:
        return text
    close = matching(text, m.end() - 1)
    return text[:m.start()] + text[close + 1:]


def variants_for(text):
    """Splits on if (HiveBees > N). Returns (N, [text for bees <= N, text for bees > N])."""
    m = re.search(r"if\s*\(\s*HiveBees\s*>\s*(\d+)\s*\)\s*\{", text)
    if not m:
        return 0, [text, text]
    if re.search(r"HiveBees", text[m.end():]):
        raise Unsupported("more than one HiveBees test")
    open_i = m.end() - 1
    close_i = matching(text, open_i)
    then_body = text[open_i + 1:close_i]
    em = re.match(r"\s*else\s*\{", text[close_i + 1:])
    if em:
        else_open = close_i + 1 + em.end() - 1
        else_close = matching(text, else_open)
        else_body = text[else_open + 1:else_close]
        tail = text[else_close + 1:]
    else:
        else_body = ""
        tail = text[close_i + 1:]
    head = text[:m.start()]
    return int(m.group(1)), [head + else_body + tail, head + then_body + tail]


def walk_branch(text):
    """The MoveMethod = "walk" branch. Refuses other if-structures."""
    m = re.search(r'if\s*\(\s*MoveMethod\s*=\s*"(\w+)"\s*\)', text)
    if not m:
        if re.search(r"\bif\b", text):
            raise Unsupported("if we do not understand")
        return text
    if len(re.findall(r"\bif\b", text)) > 1:
        raise Unsupported("more than one if")
    kind = m.group(1)
    open_i = text.index("{", m.end())
    close_i = matching(text, open_i)
    then_body = text[open_i + 1:close_i]
    em = re.match(r"\s*else\s*\{", text[close_i + 1:])
    else_body = ""
    if em:
        else_open = close_i + 1 + em.end() - 1
        else_body = text[else_open + 1:matching(text, else_open)]
    if kind == "walk":
        return then_body
    if kind == "cannon":
        if not em:
            raise Unsupported("cannon branch without a walk branch")
        return else_body
    raise Unsupported('MoveMethod "%s"' % kind)


def expand_switch(text, slot):
    """Replaces switch HiveSlot { case N: ... default: ... } with the lines for this hive slot."""
    m = re.search(r"switch\s+HiveSlot\s*", text)
    if not m:
        return text
    open_i = text.index("{", m.end())
    close_i = matching(text, open_i)
    cases, cur = {}, None
    for raw in text[open_i + 1:close_i].split("\n"):
        line = raw.split(";")[0].strip()
        cm = re.match(r"case\s+(\d+)\s*:", line)
        if cm:
            cur = int(cm.group(1))
            cases[cur] = []
            continue
        if re.match(r"default\s*:", line):
            cur = "default"
            cases[cur] = []
            continue
        if cur is not None:
            cases[cur].append(raw)
    chosen = cases.get(slot, cases.get("default", []))
    return text[:m.start()] + "\n".join(chosen) + text[close_i + 1:]


def top_args(line, call):
    """Arguments of call( ... ) at top-level commas. call includes the opening parenthesis."""
    start = line.index(call) + len(call)
    depth, cur, args = 0, "", []
    for ch in line[start:]:
        if ch == "(":
            depth += 1
        elif ch == ")":
            if depth == 0:
                args.append(cur.strip())
                return args
            depth -= 1
        elif ch == "," and depth == 0:
            args.append(cur.strip())
            cur = ""
            continue
        cur += ch
    raise Unsupported("unclosed call: " + line)


def canon(k):
    """AutoHotkey names are case-insensitive: Backkey and BackKey are the same key."""
    for name in KEYS:
        if name.lower() == k.lower():
            return name
    return None


def evaluate(expr, slot):
    return float(eval(expr, {"__builtins__": {}}, {"HiveSlot": slot}))


def translate(branch, slot):
    segs, held = [], set()
    skipped = Counter()
    for raw in branch.split("\n"):
        line = raw.split(";")[0].strip()
        if not line or line in ("{", "}"):
            continue
        low = line.lower()
        if low.startswith("nm_gotoramp"):
            skipped["ramp (we are already there)"] += 1
            continue
        if low.startswith("nm_walk"):
            args = top_args(line, line[:line.index("(") + 1])
            keys = [canon(k) for k in args[1:]]
            if not keys or any(k is None for k in keys):
                raise Unsupported("nm_Walk keys " + ",".join(args[1:]))
            segs.append(("t", sum(KEYS[k][0] for k in keys), sum(KEYS[k][1] for k in keys),
                         evaluate(args[0], slot)))
            continue
        if low.startswith("walk("):
            dx = sum(KEYS[k][0] for k in held)
            dy = sum(KEYS[k][1] for k in held)
            if dx == 0 and dy == 0:
                raise Unsupported("Walk with no key held")
            segs.append(("t", dx, dy, evaluate(top_args(line, "Walk(")[0], slot)))
            continue
        if low.startswith("jump("):
            groups = re.findall(r"\[([^\]]*)\]", line)
            if not groups:
                raise Unsupported("Jump with no steps")
            for g in groups:
                parts = [p.strip() for p in g.split(",")]
                keys = [canon(k) for k in parts[1:]]
                if not keys or any(k is None for k in keys):
                    raise Unsupported("Jump keys " + ",".join(parts[1:]))
                segs.append(("t", sum(KEYS[k][0] for k in keys), sum(KEYS[k][1] for k in keys),
                             evaluate(parts[0], slot)))
            skipped["jump press (not used)"] += 1
            continue
        m = re.match(r"(?i)^(hyper)?sleep\s*\(?\s*(.+?)\)?\s*$", line)
        if m:
            dx = sum(KEYS[k][0] for k in held)
            dy = sum(KEYS[k][1] for k in held)
            segs.append(("s", dx, dy, evaluate(m.group(2), slot) / 1000.0))
            continue
        if low.startswith("send"):
            rots = ROT.findall(line)
            for side, count in rots:
                n = int(count) if count else 1
                segs.append(("r", 0, 0, n if side == "Right" else -n))
            for key, state in KEY_EVENT.findall(line):
                key = canon(key)
                if state.lower() == "down":
                    held.add(key)
                else:
                    held.discard(key)
            if rots or KEY_EVENT.search(line):
                continue
            if "space" in low:
                skipped["jump press (not used)"] += 1
                continue
            if re.search(r"\b(e|shift)\b|sc_e", low):
                skipped["interact (E) and shift presses (replaced by destination taps)"] += 1
                continue
            raise Unsupported("send " + line)
        raise Unsupported("line " + line)
    return segs, skipped


def encode(segs):
    out = []
    for kind, dx, dy, v in segs:
        if kind == "r":
            out.append("0,0,r,%d;" % int(v))
        else:
            out.append("%d,%d,%s,%s;" % (dx, dy, kind, ("%.3f" % v).rstrip("0").rstrip(".") or "0"))
    return "".join(out)


def naive_totals(branch, slot):
    """Walk count and tile total from a plain line scan. Separate from translate()."""
    count, tiles = 0, 0.0
    for raw in branch.split("\n"):
        line = raw.split(";")[0].strip()
        if re.match(r"(?i)nm_walk\s*\(", line):
            count += 1
            tiles += evaluate(top_args(line, line[:line.index("(") + 1])[0], slot)
        elif re.match(r"Walk\s*\(", line):
            count += 1
            tiles += evaluate(top_args(line, "Walk(")[0], slot)
        elif re.match(r"(?i)jump\s*\(", line):
            for g in re.findall(r"\[([^\]]*)\]", line):
                count += 1
                tiles += evaluate(g.split(",")[0].strip(), slot)
    return count, tiles


UNSUPPORTED_IN_BRANCH = [r"\bnm_gotocannon\b", r"\bClick\b", r"Mouse", r"\bDllCall\b", r"\bif\b",
                         r"\belse\b", r"\bswitch\b", r"\bcase\b", r"\bfor\b"]


def build(raw):
    """Returns (bees threshold, [variant][slot] encoded strings, skipped counter)."""
    text = strip_jump_def(clean(raw))
    threshold, variants = variants_for(text)
    grid, skipped_all = [], Counter()
    for vtext in variants:
        row = []
        for slot in range(1, 7):
            branch = expand_switch(walk_branch(vtext), slot)
            code = re.sub(r";[^\n]*", "", branch)
            for word in UNSUPPORTED_IN_BRANCH:
                if re.search(word, code, re.I):
                    raise Unsupported("uses " + word.replace("\\b", ""))
            segs, skipped = translate(branch, slot)
            row.append(encode(segs))
            if slot == 1:
                skipped_all.update(skipped)
        grid.append(row)
    return threshold, grid, skipped_all


def main():
    if len(sys.argv) != 4:
        sys.exit(__doc__)
    paths, java_dir, test_dir = sys.argv[1], sys.argv[2], sys.argv[3]
    ported, skips, rows = [], [], []
    for f in sorted(glob.glob(os.path.join(paths, "gtc-*.ahk"))):
        slug = os.path.basename(f)[len("gtc-"):-len(".ahk")]
        raw = open(f, encoding="utf-8", errors="replace").read()
        try:
            threshold, grid, skipped = build(raw)
            name = NAME.get(slug, slug)
            ported.append((name, threshold, grid))
            text = strip_jump_def(clean(raw))
            _, variants = variants_for(text)
            for bees in (10, 50):
                vi = 1 if threshold and bees > threshold else 0
                for slot in range(1, 7):
                    branch = expand_switch(walk_branch(variants[vi]), slot)
                    count, tiles = naive_totals(branch, slot)
                    rows.append((name, slot, bees, count, tiles))
            skips.append(("OK", slug, "%d hive-bee variant(s); skipped %s" % (
                2 if threshold else 1, dict(skipped))))
        except Unsupported as e:
            skips.append(("skip", slug, str(e)))

    lines = [
        "package com.natromobile;",
        "",
        "import java.util.ArrayList;",
        "import java.util.List;",
        "",
        "// GENERATED by tools/gen_trips.py from Natro Macro v1.1.2 paths/gtc-*.ahk (GNU GPL v3). Do not edit.",
        "// Each route has variants (hive bee count) and one string per hive slot 1..6.",
        "// Entries: \"dx,dy,kind,value;\". kind t = move value tiles (1 tile = 4 studs), kind s = move (or wait",
        "// when dx=dy=0) for value seconds, kind r = camera turns, value presses (+ right, - left).",
        "public final class TripRoutes {",
        "    public static final String[] NAMES = {%s};" % ", ".join('"%s"' % n for n, _, _ in ported),
        "    /** Bee count above which the second variant is used. 0 = no bee check. */",
        "    private static final int[] BEES_OVER = {%s};" % ", ".join(str(t) for _, t, _ in ported),
        "    private static final String[][][] ROUTES = {",
    ]
    for _, _, grid in ported:
        lines.append("        {")
        for row in grid:
            lines.append("            {%s}," % ", ".join('"%s"' % s for s in row))
        lines.append("        },")
    lines += [
        "    };",
        "",
        "    private TripRoutes() {}",
        "",
        "    /** Steps from the hive to the building, for the hive slot, with 50 bees. */",
        "    public static List<Patterns.Seg> plan(String name, int hiveSlot) { return plan(name, hiveSlot, 50); }",
        "",
        "    /** Steps from the hive to the building, for the hive slot and bee count. Empty if the route is unknown. */",
        "    public static List<Patterns.Seg> plan(String name, int hiveSlot, int hiveBees) {",
        "        List<Patterns.Seg> out = new ArrayList<Patterns.Seg>();",
        "        int slot = Math.max(1, Math.min(6, hiveSlot));",
        "        for (int i = 0; i < NAMES.length; i++) {",
        "            if (!NAMES[i].equals(name)) continue;",
        "            int variant = BEES_OVER[i] > 0 && hiveBees > BEES_OVER[i] ? 1 : 0;",
        "            for (String entry : ROUTES[i][variant][slot - 1].split(\";\")) {",
        "                if (entry.isEmpty()) continue;",
        "                String[] p = entry.split(\",\");",
        "                int dx = Integer.parseInt(p[0]), dy = Integer.parseInt(p[1]);",
        "                if (p[2].equals(\"r\")) out.add(new Patterns.Seg(0, 0, 0, -1, Integer.parseInt(p[3])));",
        "                else if (p[2].equals(\"t\")) out.add(new Patterns.Seg(dx, dy, Double.parseDouble(p[3]), -1));",
        "                else out.add(new Patterns.Seg(dx, dy, 0, Double.parseDouble(p[3])));",
        "            }",
        "            break;",
        "        }",
        "        return out;",
        "    }",
        "",
        "    /** The same steps walked back: order reversed, movements turned around, camera turns undone. Waits are kept. */",
        "    public static List<Patterns.Seg> reverse(List<Patterns.Seg> steps) {",
        "        List<Patterns.Seg> out = new ArrayList<Patterns.Seg>();",
        "        for (int i = steps.size() - 1; i >= 0; i--) {",
        "            Patterns.Seg s = steps.get(i);",
        "            if (s.rotate != 0) out.add(new Patterns.Seg(0, 0, 0, -1, -s.rotate));",
        "            else if (s.isWait()) out.add(s);",
        "            else out.add(new Patterns.Seg(-s.dx, -s.dy, s.tiles, s.seconds));",
        "        }",
        "        return out;",
        "    }",
        "",
        "    /** True if the steps turn the camera. Those need the camera spot to be set. */",
        "    public static boolean hasTurns(List<Patterns.Seg> steps) {",
        "        for (Patterns.Seg s : steps) if (s.rotate != 0) return true;",
        "        return false;",
        "    }",
        "}",
        "",
    ]
    with open(os.path.join(java_dir, "TripRoutes.java"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines))

    exp = [
        "package com.natromobile;",
        "",
        "// GENERATED by tools/gen_trips.py. Walk counts and tile totals come from a plain line scan of the same",
        "// branch the translation starts from (switch, bee variant, Jump calls included). Fields: name, hive slot,",
        "// hive bees, walks, total tiles.",
        "final class TripExpectations {",
        "    static final Object[][] ROWS = {",
    ]
    exp += ['        {"%s", %d, %d, %d, %.6f},' % (n, s, b, c, t) for (n, s, b, c, t) in rows]
    exp += ["    };", "}", ""]
    with open(os.path.join(test_dir, "TripExpectations.java"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(exp))

    for status, slug, detail in skips:
        print("%-5s gtc-%-18s %s" % (status, slug, detail))
    print("ported %d of %d collect routes; %d expectation rows" % (len(ported), len(skips), len(rows)))


if __name__ == "__main__":
    main()

package com.natromobile;

import android.view.accessibility.AccessibilityEvent;
import java.util.Arrays;
import java.util.List;

/**
 * Runs the engine through common situations on the simulated clock and checks the gestures it sends.
 * Each check prints FAIL with its name when it does not hold.
 */
public class RunTests {
    static int passed = 0, failed = 0;

    static void check(boolean ok, String name) {
        if (ok) passed++;
        else { failed++; System.out.println("FAIL  " + name); }
    }

    /** A fresh service with a clean clock, screen and preferences. */
    static MacroAccessibilityService start() {
        Sim.reset();
        MacroAccessibilityService.disableJitterForTests = true;
        MacroAccessibilityService s = new MacroAccessibilityService();
        s.onServiceConnected();
        return s;
    }

    static void setJoystick(MacroAccessibilityService s) {
        Config c = new Config(s);
        c.joyX = 300;
        c.joyY = 1500;
        c.walkFirst = false; // tests that need pure pattern gestures turn walk off
        c.save();
    }

    /** Joystick + bag + convert spots for convert/fail-safe tests. */
    static void setCoreSpots(MacroAccessibilityService s) {
        Config c = new Config(s);
        c.joyX = 300;
        c.joyY = 1500;
        c.bagX = 100;
        c.bagY = 80;
        c.convX = 800;
        c.convY = 1200;
        c.walkFirst = false;
        c.save();
    }

    /** Sets the whole 7x7 block the disconnect spot is averaged over. */
    static void setRegion(int x, int y, int color) {
        for (int dy = -3; dy <= 3; dy++) for (int dx = -3; dx <= 3; dx++) Sim.setPixel(x + dx, y + dy, color);
    }

    static void clearRegion(int x, int y) {
        for (int dy = -3; dy <= 3; dy++) for (int dx = -3; dx <= 3; dx++) Sim.clearPixel(x + dx, y + dy);
    }

    /** Taps within tol pixels of (x, y). Picture matching finds a button to within its sampling step. */
    static int countTapsNear(int x, int y, int tol) {
        int n = 0;
        for (Sim.Gesture g : Sim.gestures) {
            if (Math.abs(g.x0 - x) <= tol && Math.abs(g.y0 - y) <= tol && g.x1 == g.x0 && g.y1 == g.y0 && g.duration == 60) n++;
        }
        return n;
    }

    static int countTaps(int x, int y) {
        int n = 0;
        for (Sim.Gesture g : Sim.gestures) {
            if (g.x0 == x && g.y0 == y && g.x1 == x && g.y1 == y && g.duration == 60) n++;
        }
        return n;
    }

    static int indexOfTap(int x, int y, int after) {
        for (int i = after + 1; i < Sim.gestures.size(); i++) {
            Sim.Gesture g = Sim.gestures.get(i);
            if (g.x0 == x && g.y0 == y && g.x1 == x && g.y1 == y && g.duration == 60) return i;
        }
        return -1;
    }

    static int indexOfEnd(int x1, int y1, int after) {
        for (int i = after + 1; i < Sim.gestures.size(); i++) {
            Sim.Gesture g = Sim.gestures.get(i);
            if (g.x1 == x1 && g.y1 == y1) return i;
        }
        return -1;
    }

    public static void main(String[] args) {
        coordinatorAndSandbox();
        pureLogic();
        engine();
        phase4();
        phase5();
        phase6();
        System.out.println(passed + " passed, " + failed + " failed");
        if (failed > 0) System.exit(1);
    }


    static void coordinatorAndSandbox() {
        AutomationTaskCoordinator arbiter = new AutomationTaskCoordinator();
        AutomationTaskCoordinator.Pending p = new AutomationTaskCoordinator.Pending();
        p.farming = true; p.quest = true; p.conversion = true; p.recovery = true;
        check(arbiter.choose(p) == AutomationTaskCoordinator.Task.RECOVERY,
            "recovery outranks conversion, quest, and farming");
        p.recovery = false;
        check(arbiter.choose(p) == AutomationTaskCoordinator.Task.CONVERSION,
            "conversion outranks quest and farming");
        p.accessibilityLost = true;
        check(arbiter.choose(p) == AutomationTaskCoordinator.Task.ACCESSIBILITY_LOST,
            "accessibility loss outranks ordinary tasks");
        p.userInterruption = true;
        check(arbiter.choose(p) == AutomationTaskCoordinator.Task.USER_INTERRUPTION,
            "user interruption outranks accessibility loss");
        arbiter.emergencyStop();
        check(arbiter.choose(p) == AutomationTaskCoordinator.Task.EMERGENCY_STOP,
            "emergency stop has absolute priority");
        arbiter.resetEmergencyStop();
        check(!arbiter.isEmergencyLatched(), "emergency latch resets explicitly");

        SandboxEngine.Clock clock = new SandboxEngine.Clock();
        final int[] events = {0};
        clock.schedule(20, () -> events[0] += 2);
        clock.schedule(10, () -> events[0] += 1);
        clock.advanceTo(10);
        check(events[0] == 1 && clock.now() == 10, "sandbox clock executes due events in time order");
        clock.advanceTo(20);
        check(events[0] == 3 && clock.queuedEvents() == 0, "sandbox clock drains scheduled events");

        SandboxEngine.Faults faults = new SandboxEngine.Faults();
        SandboxEngine.Session session = new SandboxEngine.Session(faults);
        session.start();
        faults.failNextScreenshots(1);
        check(!session.captureScreenshot() && session.captureScreenshot(),
            "sandbox injects one screenshot failure then recovers");
        faults.failNextGestures(1);
        check(!session.submitGesture() && session.submitGesture(),
            "sandbox injects one gesture failure then recovers");
        session.accessibilityLost();
        check(session.state() == SandboxEngine.Session.State.ACCESSIBILITY_UNAVAILABLE,
            "sandbox stops session when accessibility is lost");
    }

    static void pureLogic() {
        check(BagReader.percentFromColor(0xF70017) == 100, "bag reads 100% for the full color");
        check(BagReader.percentFromColor(0x000000) == 0, "bag reads 0% for black");
        check(BagReader.percentFromColor(0x4DF07E) == 25, "bag reads 25%");
        BagReader.Filter f = new BagReader.Filter(6);
        int last = 0;
        for (int v : new int[]{0, 0, 100, 100, 100, 100}) last = f.add(v);
        check(last == 67, "bag filter averages the last six readings");

        // Phase 2 AutoSense scene + bag strip detection
        Sim.reset();
        // Paint a short pollen-bar run at top-left
        for (int x = 20; x < 60; x++) for (int y = 30; y < 40; y++) Sim.setPixel(x, y, 0x4DF07E);
        // Green field mid-screen
        for (int x = 300; x < 800; x += 20) for (int y = 600; y < 1800; y += 20) Sim.setPixel(x, y, 0x2A8B3A);
        android.graphics.Bitmap fake = new android.graphics.Bitmap();
        AutoSense.Result sense = AutoSense.sense(fake, 1080, 2400);
        check(sense.bagOk, "AutoSense finds bag strip from pollen colors");
        check(sense.scene == AutoSense.SCENE_ON_FIELD || sense.scene == AutoSense.SCENE_UNKNOWN,
            "AutoSense scene is field or unknown with green + bag: " + sense.note);

        Sim.reset();
        for (int x = 20; x < 60; x++) for (int y = 30; y < 40; y++) Sim.setPixel(x, y, 0x4DF07E);
        // Warm convert-like button mid-right
        for (int x = 700; x < 780; x++) for (int y = 1000; y < 1100; y++) Sim.setPixel(x, y, 0xF0C020);
        // Brown hive-pad zone bottom-center
        for (int x = 400; x < 680; x += 4) for (int y = 1600; y < 1900; y += 4) Sim.setPixel(x, y, 0x8B6914);
        sense = AutoSense.sense(new android.graphics.Bitmap(), 1080, 2400);
        check(sense.bagOk, "AutoSense bag still found with convert present");
        check(sense.convOk || sense.scene == AutoSense.SCENE_AT_HIVE,
            "AutoSense sees convert or classifies at-hive: " + sense.note);
        if (sense.scene == AutoSense.SCENE_AT_HIVE) {
            check(sense.hivePadOk, "AutoSense hive-pad ok when at-hive");
            check(sense.hivePadX > 200 && sense.hivePadX < 900, "hive-pad x in mid band: " + sense.hivePadX);
        }
        check(AutoSense.sceneOnly(null) == AutoSense.SCENE_UNKNOWN, "sceneOnly null is UNKNOWN");

        // Smart quest claim detection
        Sim.reset();
        // Full solid green Complete rows (wide) should claim
        for (int x = 40; x < 300; x++) for (int y = 350; y < 650; y++) Sim.setPixel(x, y, 0x28D040);
        AutoSense.Result qp = AutoSense.questProbe(new android.graphics.Bitmap());
        check(qp.claimOk, "wide green Complete row is claimOk");
        // Thin green progress fill on left edge should NOT claim
        Sim.reset();
        for (int x = 40; x < 280; x++) for (int y = 400; y < 700; y++) Sim.setPixel(x, y, 0xE07070);
        for (int x = 40; x < 55; x++) for (int y = 400; y < 700; y++) Sim.setPixel(x, y, 0x28D040);
        qp = AutoSense.questProbe(new android.graphics.Bitmap());
        check(!qp.claimOk, "thin green progress fill is not claimOk");
        // Red incomplete only
        Sim.reset();
        for (int x = 40; x < 280; x++) for (int y = 400; y < 700; y++) Sim.setPixel(x, y, 0xE07070);
        qp = AutoSense.questProbe(new android.graphics.Bitmap());
        check(!qp.claimOk, "red incomplete is not claimOk");

        check(AutoSense.SCENE_AT_HIVE != AutoSense.SCENE_ON_FIELD, "scene constants differ");

        
        // Phase 3 field presets
        for (String name : FieldRoutes.NAMES) {
            FieldPresets.Preset pr = FieldPresets.forField(name);
            check(pr.pattern != null && pr.pattern.length() > 0, "preset pattern for " + name);
            check(pr.size != null && pr.size.length() > 0, "preset size for " + name);
        }
        FieldPresets.Preset pine = FieldPresets.forField("Pine Tree");
        check("Snake".equals(pine.pattern) && "L".equals(pine.size), "Pine Tree preset Snake L");
        FieldPresets.Preset stump = FieldPresets.forField("Stump");
        check(stump.facingCorner, "Stump preset faces corner");
        check(FieldPresets.forField("Nope").pattern.equals("Snake"), "unknown field gets generic Snake");

        check(FieldRoutes.NAMES.length == 17, "17 fields");
        for (String name : FieldRoutes.NAMES) check(!FieldRoutes.plan(name).isEmpty(), "route exists for " + name);
        check(FieldRoutes.plan("Nope").isEmpty(), "unknown field has no route");
        Patterns.Seg first = FieldRoutes.plan("Clover").get(0);
        check(first.dx == -1 && first.dy == 1 && Math.abs(first.tiles - 44.75) < 1e-6, "Clover's first step matches Natro");

        for (String p : Patterns.NAMES) for (String size : Patterns.SIZES) {
            check(!Patterns.build(p, size, 2, false, false, false).isEmpty(), "pattern " + p + " " + size + " has steps");
        }

        List<int[]> taps = Config.parseTaps("1,2;3,4;bad;5,6");
        check(taps.size() == 3 && taps.get(1)[0] == 3 && taps.get(2)[1] == 6, "taps parse and skip bad entries");
        check(Config.parseTaps("").isEmpty(), "empty taps parse to nothing");
        // Phase 4 sequence strings parse like item taps
        check(Config.parseTaps("10,20;30,40").size() == 2, "booster-style taps parse");

        check(RobloxLink.toRobloxUri("https://www.roblox.com/games/1537690962/Bee-Swarm-Simulator?privateServerLinkCode=123456")
            .equals("roblox://placeID=1537690962&linkCode=123456"), "a game link becomes a roblox:// link");
        check(RobloxLink.toRobloxUri("roblox://placeID=1&linkCode=abc").equals("roblox://placeID=1&linkCode=abc"), "a roblox:// link is kept");
        check(RobloxLink.toRobloxUri("https://www.roblox.com/share?code=abc&type=Server").startsWith("https://"), "a share link is kept as it is");
        check(RobloxLink.toRobloxUri("").equals(""), "an empty link stays empty");
    }

    static void engine() {
        // Phase 1: smart defaults fill missing spots so it can start without manual set.
        MacroAccessibilityService s = start();
        s.startMacro();
        check(s.isRunning(), "starts with smart-default joystick when none was saved");
        s.stopMacro();

        // The first move starts at the joystick and goes the way Lines goes first (forward).
        s = start();
        setJoystick(s);
        Config c = new Config(s);
        c.pattern = "Lines";
        c.size = "M";
        c.reps = 1;
        c.walkFirst = false; // test the pattern itself, not the walk-to-field path
        c.save();
        s.startMacro();
        Sim.runUntil(500);
        check(!Sim.gestures.isEmpty(), "sent at least one gesture");
        Sim.Gesture g0 = Sim.gestures.get(0);
        check(g0.x0 == 300 && g0.y0 == 1500, "first move starts at the joystick: " + g0);
        check(g0.x1 == 300 && g0.y1 == 1390, "Lines goes forward first: " + g0);
        check(g0.duration == 60, "the slide to a direction takes 60 ms: " + g0);
        check(Sim.warnings.isEmpty(), "no stroke warnings: " + Sim.warnings);

        // Stop lifts the thumb and sends nothing more.
        Sim.runUntil(3000);
        s.stopMacro();
        int atStop = Sim.gestures.size();
        Sim.runUntil(20000);
        check(Sim.gestures.size() <= atStop + 1, "nothing sent after stop except the lift");
        Sim.Gesture last = Sim.gestures.get(Sim.gestures.size() - 1);
        check(!last.willContinue && last.duration == 20, "the last gesture lifts the thumb: " + last);
        check(!s.isRunning(), "not running after stop");

        // A timed item is used right at start, then again after the interval.
        s = start();
        setJoystick(s);
        c = new Config(s);
        c.pattern = "Snake";
        c.itemMinutes = 1;
        c.itemSteps = "500,900";
        c.save();
        s.startMacro();
        Sim.runUntil(2000);
        check(countTaps(500, 900) == 1, "timed item is used at start");
        Sim.runUntil(70000);
        check(countTaps(500, 900) == 2, "timed item is used again after a minute");

        // A full bag with the Stop option stops the macro.
        s = start();
        setJoystick(s);
        c = new Config(s);
        c.pattern = "Lines";
        c.bagX = 1000;
        c.bagY = 80;
        c.fullAction = 1;
        c.save();
        Sim.bagColor = 0xF70017;
        s.startMacro();
        Sim.runUntil(20000);
        check(!s.isRunning(), "stops when the bag is full (Stop option)");
        check(MacroAccessibilityService.status.contains("full"), "says the bag is full");

        // A refused gesture stops the macro with a message.
        s = start();
        setJoystick(s);
        Sim.acceptGestures = false;
        s.startMacro();
        check(!s.isRunning(), "a refused gesture stops the macro");
        check(MacroAccessibilityService.status.contains("refused"), "says a gesture was refused");
        Sim.acceptGestures = true;

        // A cancelled gesture stops the macro with a message.
        s = start();
        setJoystick(s);
        Sim.cancelAll = true;
        s.startMacro();
        Sim.runUntil(500);
        check(!s.isRunning(), "a cancelled gesture stops the macro");
        check(MacroAccessibilityService.status.contains("cancelled"), "says a gesture was cancelled");
        Sim.cancelAll = false;

        // A full bag with Convert: reset taps, convert tap, walk back to the field, then farm again.
        s = start();
        setJoystick(s);
        c = new Config(s);
        c.pattern = "Snake";
        c.bagX = 1000;
        c.bagY = 80;
        c.convX = 500;
        c.convY = 1200;
        c.resetSteps = "100,100";
        c.respawnWait = 1;
        c.fullAction = 2;
        c.returnToField = true;
        c.field = "Clover";
        c.save();
        Sim.bagColor = 0xF70017;
        s.startMacro();
        Sim.runUntil(12000);
        int resetIdx = indexOfTap(100, 100, -1);
        int convIdx = indexOfTap(500, 1200, -1);
        check(resetIdx >= 0, "reset tap is sent while converting");
        check(convIdx > resetIdx, "convert tap comes after the reset tap");
        Sim.bagColor = 0;
        Sim.runUntil(60000);
        check(Sim.saw("Walking back to Clover"), "walks back to the field once the bag is empty");
        int walkIdx = indexOfEnd(222, 1578, convIdx);
        check(walkIdx > convIdx, "the first walk-back step follows Clover's route");
        check(indexOfEnd(190, 1500, walkIdx) > walkIdx, "farming resumes after the walk back");
        check(s.isRunning(), "still running after converting");
        check(Sim.warnings.isEmpty(), "the whole convert run keeps gesture paths continuous: " + Sim.warnings);

        // Walk first: reset, then the ramp, then the route, before farming.
        s = start();
        setJoystick(s);
        c = new Config(s);
        c.pattern = "Snake";
        c.resetSteps = "100,100";
        c.respawnWait = 1;
        c.walkFirst = true;
        c.field = "Clover";
        c.save();
        s.startMacro();
        Sim.runUntil(20000);
        int r = indexOfTap(100, 100, -1);
        int route = indexOfEnd(222, 1578, r);
        check(r >= 0 && route > r, "walk first: reset tap, then the route to the field");

        // The joystick test walks right for a second.
        s = start();
        setJoystick(s);
        s.testMove(4000);
        Sim.runUntil(4100);
        Sim.Gesture t0 = Sim.gestures.get(0);
        check(t0.x1 == 410 && t0.y1 == 1500, "joystick test moves right: " + t0);
        Sim.runUntil(20000);
        check(Sim.saw("Test finished"), "joystick test finishes");

        // The item test taps the saved item steps once.
        s = start();
        setJoystick(s);
        c = new Config(s);
        c.itemSteps = "700,800";
        c.save();
        s.testItem(4000);
        Sim.runUntil(20000);
        check(countTaps(700, 800) == 1, "item test taps the saved item once");
        check(Sim.saw("Item test finished"), "item test finishes");

        // Disconnect with no private server link: stops with a message and opens nothing.
        final String link = "roblox://placeID=1&linkCode=abc";
        s = start();
        setJoystick(s);
        c = new Config(s);
        c.pattern = "Snake";
        c.dcX = 900;
        c.dcY = 1800;
        c.dcColor = 0x3366CC;
        c.save();
        s.startMacro();
        Sim.runUntil(20000);
        setRegion(900, 1800, 0x3366CC);
        Sim.runUntil(30000);
        check(!s.isRunning() && MacroAccessibilityService.status.contains("private server link"),
            "disconnect with no link stops with a message");
        check(Sim.launched.isEmpty(), "nothing is opened when there is no link");

        // A normal screen at the disconnect spot does not trigger a rejoin.
        s = start();
        setJoystick(s);
        c = new Config(s);
        c.pattern = "Snake";
        c.dcX = 900;
        c.dcY = 1800;
        c.dcColor = 0x3366CC;
        c.privateLink = link;
        c.rejoinSec = 5;
        c.save();
        s.startMacro();
        Sim.runUntil(60000);
        check(Sim.launched.isEmpty(), "a normal screen does not trigger a rejoin");
        check(s.isRunning(), "still farming on a normal screen");

        // The disconnect appears: the link is opened, then reset, walk back to the field, and farming resumes.
        s = start();
        setJoystick(s);
        c = new Config(s);
        c.pattern = "Snake";
        c.dcX = 900;
        c.dcY = 1800;
        c.dcColor = 0x3366CC;
        c.privateLink = link;
        c.rejoinSec = 5;
        c.resetSteps = "100,100";
        c.respawnWait = 1;
        c.field = "Clover";
        c.save();
        s.startMacro();
        Sim.runUntil(20000);
        check(indexOfTap(100, 100, -1) < 0, "no reset before the disconnect");
        setRegion(900, 1800, 0x3366CC);
        Sim.runUntil(30000);
        check(Sim.launched.contains(link), "a disconnect opens the private server link");
        clearRegion(900, 1800);   // Roblox has rejoined, so the disconnect screen is gone
        Sim.runUntil(70000);
        int reset = indexOfTap(100, 100, -1);
        check(reset >= 0 && Sim.gestures.get(reset).at >= 24000, "the reset waits for the rejoin");
        check(Sim.saw("Walking to Clover"), "walks back to the field after rejoining");
        check(indexOfEnd(222, 1578, reset) > reset, "the route follows the reset");
        check(s.isRunning(), "running again after rejoining");
        check(Sim.launched.size() == 1, "rejoins once, not in a loop: " + Sim.launched);
        check(Sim.warnings.isEmpty(), "rejoin keeps gesture paths continuous: " + Sim.warnings);

        // The Advanced test button rejoins while farming.
        s = start();
        setJoystick(s);
        c = new Config(s);
        c.pattern = "Lines";
        c.privateLink = link;
        c.rejoinSec = 5;
        c.save();
        s.startMacro();
        Sim.runUntil(3000);
        s.rejoinNow();
        check(Sim.launched.contains(link), "the test rejoin opens the link");
        Sim.runUntil(20000);
        check(s.isRunning(), "running again after a test rejoin");

        // Roblox leaving the screen for 8 seconds opens the link; Roblox coming back clears the timer.
        s = start();
        setJoystick(s);
        c = new Config(s);
        c.pattern = "Snake";
        c.privateLink = link;
        c.rejoinSec = 5;
        c.save();
        s.startMacro();
        Sim.runUntil(5000);
        s.onAccessibilityEvent(new AccessibilityEvent("com.android.launcher"));
        Sim.runUntil(6000);
        s.onAccessibilityEvent(new AccessibilityEvent("com.roblox.client"));
        Sim.runUntil(30000);
        check(Sim.launched.isEmpty(), "a short switch away does not rejoin once Roblox is back");
        s.onAccessibilityEvent(new AccessibilityEvent("com.android.launcher"));
        Sim.runUntil(40000);
        check(Sim.launched.contains(link), "Roblox off the screen for 8 seconds opens the link");

        // The system UI and the app's own windows do not count as leaving.
        s = start();
        setJoystick(s);
        c = new Config(s);
        c.pattern = "Snake";
        c.privateLink = link;
        c.rejoinSec = 5;
        c.save();
        s.startMacro();
        Sim.runUntil(2000);
        s.onAccessibilityEvent(new AccessibilityEvent("com.android.systemui"));
        s.onAccessibilityEvent(new AccessibilityEvent("com.natromobile"));
        Sim.runUntil(30000);
        check(Sim.launched.isEmpty(), "system UI and the app's own windows are ignored");

        // The watch can be turned off.
        s = start();
        setJoystick(s);
        c = new Config(s);
        c.pattern = "Snake";
        c.privateLink = link;
        c.rejoinSec = 5;
        c.watchRoblox = false;
        c.save();
        s.startMacro();
        Sim.runUntil(2000);
        s.onAccessibilityEvent(new AccessibilityEvent("com.android.launcher"));
        Sim.runUntil(30000);
        check(Sim.launched.isEmpty(), "the Roblox watch can be turned off");

        // Roblox gone with no link stops with a message.
        s = start();
        setJoystick(s);
        c = new Config(s);
        c.pattern = "Snake";
        c.rejoinSec = 5;
        c.save();
        s.startMacro();
        Sim.runUntil(2000);
        s.onAccessibilityEvent(new AccessibilityEvent("com.android.launcher"));
        Sim.runUntil(15000);
        check(!s.isRunning() && MacroAccessibilityService.status.contains("private server link"),
            "Roblox gone with no link stops with a message");

        // Window events during a rejoin (a chooser, say) do not start a second rejoin.
        s = start();
        setJoystick(s);
        c = new Config(s);
        c.pattern = "Snake";
        c.privateLink = link;
        c.rejoinSec = 5;
        c.save();
        s.startMacro();
        Sim.runUntil(2000);
        s.onAccessibilityEvent(new AccessibilityEvent("com.android.launcher"));
        Sim.runUntil(12000);
        check(Sim.launched.size() == 1, "the first rejoin started");
        s.onAccessibilityEvent(new AccessibilityEvent("com.android.intentresolver"));
        Sim.runUntil(30000);
        check(Sim.launched.size() == 1, "window events during a rejoin are ignored: " + Sim.launched);

        // A game link is opened as a roblox:// link.
        s = start();
        setJoystick(s);
        c = new Config(s);
        c.pattern = "Lines";
        c.privateLink = "https://www.roblox.com/games/1537690962/Bee-Swarm-Simulator?privateServerLinkCode=123456";
        c.rejoinSec = 5;
        c.save();
        s.startMacro();
        Sim.runUntil(1000);
        s.rejoinNow();
        check(Sim.launched.contains("roblox://placeID=1537690962&linkCode=123456"), "a game link is opened as a roblox:// link");

        // Saving the disconnect spot records the average color around it.
        s = start();
        setJoystick(s);
        setRegion(900, 1800, 0x3366CC);
        s.savePoint("dc", 900, 1800);
        Sim.runUntil(2000);
        Config saved = new Config(s);
        check(saved.dcX == 900 && saved.dcY == 1800 && saved.dcColor == 0x3366CC, "saving the disconnect spot records its color");

        // One stray dark pixel does not break the match; a different screen does not match.
        s = start();
        setJoystick(s);
        c = new Config(s);
        c.dcX = 900;
        c.dcY = 1800;
        c.dcColor = 0x3366CC;
        c.save();
        setRegion(900, 1800, 0x3366CC);
        Sim.setPixel(900, 1800, 0x000000);
        s.checkDisconnectSpot(500);
        Sim.runUntil(1000);
        check(MacroAccessibilityService.status.startsWith("Matches"), "one stray dark pixel does not break the match: " + MacroAccessibilityService.status);
        setRegion(900, 1800, 0x000000);
        s.checkDisconnectSpot(500);
        Sim.runUntil(2000);
        check(MacroAccessibilityService.status.startsWith("Does not match"), "a different screen does not match: " + MacroAccessibilityService.status);
    }

    /** Phase 4: the four ported patterns, the walk-speed calibration, and the walk check. */
    static void phase4() {
        int rows = 0;
        for (Object[] row : PatternExpectations.ROWS) {
            rows++;
            String name = (String) row[0];
            double size = ((Number) row[1]).doubleValue();
            int reps = ((Number) row[2]).intValue();
            boolean facing = (Boolean) row[3];
            int walks = ((Number) row[4]).intValue();
            double tiles = ((Number) row[5]).doubleValue();
            int pauses = ((Number) row[6]).intValue();
            double secs = ((Number) row[7]).doubleValue();
            int heldEnd = ((Number) row[8]).intValue();
            PatternBuilder pb = new PatternBuilder(false, false);
            ExtraPatterns.build(name, pb, size, reps, facing);
            int gw = 0, gp = 0;
            double gt = 0, gs = 0;
            for (Patterns.Seg sg : pb.steps()) {
                if (sg.isWait()) { gp++; gs += sg.seconds; }
                else { gw++; gt += sg.tiles; }
            }
            String label = name + " size " + size + " reps " + reps + " facing " + facing;
            check(gw == walks && gp == pauses && Math.abs(gt - tiles) < 1e-4 && Math.abs(gs - secs) < 1e-4
                    && pb.heldKeys() == heldEnd,
                label + " matches Natro's file (walks " + gw + "/" + walks + ", tiles " + gt + "/" + tiles + ")");
        }
        check(rows == 48, "48 pattern rows checked, found " + rows);
        for (String name : new String[]{"Auryn", "CornerXSnake", "SuperCat", "e_lol"}) {
            check(!Patterns.build(name, "M", 2, false, false, false).isEmpty(), name + " is wired into the picker's builder");
        }

        check(Math.abs(Calibration.speedFor(48f, 10, 8) - 38.4f) < 1e-3, "8 tiles of 10 scales 48 to 38.4");
        check(Calibration.speedFor(48f, 10, 10) == 48f, "exact distance keeps the speed");
        check(Calibration.speedFor(48f, 10, 0) == 48f, "zero distance keeps the speed");
        check(Calibration.speedFor(48f, 10, 100) == 60f, "speed is capped at the slider top");
        check(Calibration.speedFor(48f, 10, 1) == 10f, "speed is floored at the slider bottom");

        MacroAccessibilityService s = start();
        setJoystick(s);
        s.walkCheck(500);
        Sim.runUntil(1000);
        check(!Sim.gestures.isEmpty(), "walk check sends a move");
        Sim.Gesture g = Sim.gestures.get(0);
        check(g.x0 == 300 && g.y0 == 1500 && g.x1 > g.x0 && g.y1 == g.y0, "walk check moves right from the joystick: " + g);
        Sim.runUntil(20000);
        check(Sim.saw("Walk check finished"), "walk check finishes and asks for the distance");
        check(!s.isRunning(), "walk check leaves the macro stopped");
    }

    /** Phase 5: collect routes from Natro, camera turns, hive-slot and bee variants, and trips from the hive. */
    static void phase5() {
        int rows = 0;
        for (Object[] row : TripExpectations.ROWS) {
            rows++;
            String name = (String) row[0];
            int slot = ((Number) row[1]).intValue();
            int bees = ((Number) row[2]).intValue();
            int walks = ((Number) row[3]).intValue();
            double tiles = ((Number) row[4]).doubleValue();
            int gw = 0;
            double gt = 0;
            for (Patterns.Seg sg : TripRoutes.plan(name, slot, bees)) {
                if (!sg.isWait() && sg.seconds < 0 && sg.rotate == 0) { gw++; gt += sg.tiles; }
            }
            check(gw == walks && Math.abs(gt - tiles) < 1e-4,
                name + " slot " + slot + " bees " + bees + " matches Natro's walk lines (walks " + gw + "/" + walks
                    + ", tiles " + gt + "/" + tiles + ")");
        }
        check(rows == TripRoutes.NAMES.length * 12, rows + " route-slot-bee rows checked");
        check(TripRoutes.NAMES.length == 28, "28 collect routes are translated (the 3 cannon routes are left out), found "
            + TripRoutes.NAMES.length);

        int withTurns = 0;
        String turnsName = null;
        for (String n : TripRoutes.NAMES) {
            List<Patterns.Seg> there = TripRoutes.plan(n, 3, 50);
            check(!there.isEmpty(), n + " has a walking route");
            List<Patterns.Seg> back = TripRoutes.reverse(there);
            check(back.size() == there.size(), n + " walked back has the same number of steps");
            double x = 0, y = 0, bx = 0, by = 0;
            int rot = 0, brot = 0;
            for (Patterns.Seg sg : there) {
                if (sg.rotate != 0) rot += sg.rotate;
                else if (!sg.isWait() && sg.seconds < 0) { x += sg.dx * sg.tiles; y += sg.dy * sg.tiles; }
            }
            for (Patterns.Seg sg : back) {
                if (sg.rotate != 0) brot += sg.rotate;
                else if (!sg.isWait() && sg.seconds < 0) { bx += sg.dx * sg.tiles; by += sg.dy * sg.tiles; }
            }
            check(Math.abs(bx + x) < 1e-6 && Math.abs(by + y) < 1e-6, n + ": walking back undoes the walk there");
            check(brot == -rot, n + ": walking back undoes its camera turns");
            if (TripRoutes.hasTurns(there)) { withTurns++; if (turnsName == null) turnsName = n; }
        }
        check(withTurns > 0 && turnsName != null, "some routes turn the camera: " + withTurns);
        check(TripRoutes.plan("Nope", 1, 50).isEmpty(), "unknown trip route has no steps");

        // Strawberry dispenser checks the bee count: two different routes.
        List<Patterns.Seg> few = TripRoutes.plan("Strawberry dispenser", 1, 10);
        List<Patterns.Seg> many = TripRoutes.plan("Strawberry dispenser", 1, 50);
        check(few.size() != many.size(), "the bee count picks a different strawberry route");

        // A due trip runs after the bag empties at the hive: convert, trip, walk back to the field.
        MacroAccessibilityService s = start();
        setJoystick(s);
        Config c = new Config(s);
        c.pattern = "Snake";
        c.bagX = 1000;
        c.bagY = 80;
        c.convX = 500;
        c.convY = 1200;
        c.resetSteps = "100,100";
        c.respawnWait = 1;
        c.fullAction = 2;
        c.returnToField = true;
        c.field = "Clover";
        c.tripRoute[0] = "Honey dispenser";
        c.tripMinutes[0] = 60;
        c.tripSteps[0] = "700,800";
        c.save();
        Sim.bagColor = 0xF70017;
        s.startMacro();
        Sim.runUntil(12000);
        Sim.bagColor = 0;
        Sim.runUntil(90000);
        int convIdx = indexOfTap(500, 1200, -1);
        int tripIdx = indexOfTap(700, 800, -1);
        check(Sim.saw("Trip: Honey dispenser"), "a due trip runs when the bag empties at the hive");
        check(convIdx >= 0 && tripIdx > convIdx, "the trip comes after the convert tap");
        check(indexOfEnd(222, 1578, tripIdx) > tripIdx, "after the trip, the walk back to the field follows");
        check(Sim.saw("Walking back to Clover"), "walks back to the field after the trip");
        check(Sim.warnings.isEmpty(), "trip keeps gesture paths continuous: " + Sim.warnings);

        // With no trip set up, a convert makes no trip.
        s = start();
        setJoystick(s);
        c = new Config(s);
        c.pattern = "Snake";
        c.bagX = 1000;
        c.bagY = 80;
        c.convX = 500;
        c.convY = 1200;
        c.resetSteps = "100,100";
        c.respawnWait = 1;
        c.fullAction = 2;
        c.returnToField = true;
        c.field = "Clover";
        c.save();
        Sim.bagColor = 0xF70017;
        s.startMacro();
        Sim.runUntil(12000);
        Sim.bagColor = 0;
        Sim.runUntil(90000);
        check(!Sim.saw("Trip: "), "no trip runs when none is set up");

        // The trip test taps its saved spot once and stops.
        s = start();
        setJoystick(s);
        c = new Config(s);
        c.tripRoute[1] = "Wreath";
        c.tripSteps[1] = "900,950";
        c.save();
        s.testTrip(1, 500);
        Sim.runUntil(30000);
        check(countTaps(900, 950) == 1, "trip test taps the saved spot once");
        check(Sim.saw("Trip test finished"), "trip test finishes");
        check(!s.isRunning(), "trip test leaves the macro stopped");

        // A route that turns the camera swipes at the camera spot.
        s = start();
        setJoystick(s);
        c = new Config(s);
        c.camX = 200;
        c.camY = 1800;
        c.tripRoute[0] = turnsName;
        c.tripSteps[0] = "";
        c.save();
        s.testTrip(0, 500);
        Sim.runUntil(600000);
        boolean swiped = false;
        for (Sim.Gesture g : Sim.gestures) if (g.x0 == 200 && g.y0 == 1800 && g.duration == 300) swiped = true;
        check(swiped, turnsName + " swipes the camera at the camera spot");
        check(Sim.saw("Trip test finished"), turnsName + " finishes its trip test");

        // Without a camera spot, a route that turns is skipped with a message.
        s = start();
        setJoystick(s);
        c = new Config(s);
        c.tripRoute[0] = turnsName;
        c.save();
        s.testTrip(0, 500);
        Sim.runUntil(5000);
        check(Sim.saw("Set the camera spot"), "a route that turns is skipped without a camera spot");
        check(Sim.gestures.size() <= 2, "nothing is walked when the trip is skipped: " + Sim.gestures.size());
    }

    /** A picture pattern that is easy to tell apart: each 4x4 cell gets its own value. */
    static int patternCell(int ci, int cj) {
        return ((ci * 37 + cj * 91) % 200) + 20;
    }

    /** Paints the 48x48 picture with its top-left at (ox, oy) on the simulated screen. */
    static void setPicture(int ox, int oy) {
        for (int dy = 0; dy < 48; dy++) {
            for (int dx = 0; dx < 48; dx++) {
                int v = patternCell(dx / 4, dy / 4);
                Sim.setPixel(ox + dx, oy + dy, v * 0x010101);
            }
        }
    }

    static void clearPicture(int ox, int oy) {
        for (int dy = 0; dy < 48; dy++) for (int dx = 0; dx < 48; dx++) Sim.clearPixel(ox + dx, oy + dy);
    }

    /** Template matching: the pure matcher, then the Make Honey picture on the simulated screen. */
    static void phase6() {
        int gw = 60, gh = 50;
        int[] grid = new int[gw * gh];
        for (int j = 0; j < gh; j++) for (int i = 0; i < gw; i++) grid[j * gw + i] = (i * 37 + j * 91 + (i * j) % 17) % 256;
        int pw = 12, ph = 10, px = 20, py = 30;
        int[] pic = new int[pw * ph];
        for (int j = 0; j < ph; j++) for (int i = 0; i < pw; i++) pic[j * pw + i] = grid[(py + j) * gw + px + i];
        TemplateMatcher.Match m = TemplateMatcher.find(grid, gw, gh, pic, pw, ph);
        check(m != null && m.x == px && m.y == py && m.score > 0.99, "a picture is found where it is");

        int[] noisy = pic.clone();
        for (int k = 0; k < noisy.length; k += 7) noisy[k] = Math.min(255, noisy[k] + 6);
        m = TemplateMatcher.find(grid, gw, gh, noisy, pw, ph);
        check(m != null && m.x == px && m.y == py, "a picture with a little noise is still found");

        int[] other = new int[pw * ph];
        for (int k = 0; k < other.length; k++) other[k] = (k * 131 + 7) % 256;
        check(TemplateMatcher.find(grid, gw, gh, other, pw, ph) == null, "a picture that is not on the screen is not found");

        int[] flat = new int[pw * ph];
        Arrays.fill(flat, 100);
        check(TemplateMatcher.find(grid, gw, gh, flat, pw, ph) == null, "a plain picture is never reported as found");

        TemplateMatcher.Template back = TemplateMatcher.decode(TemplateMatcher.encode(pw, ph, pic));
        check(back != null && back.w == pw && back.h == ph && Arrays.equals(back.v, pic), "a picture survives saving and loading");
        check(TemplateMatcher.decode("") == null && TemplateMatcher.decode("garbage") == null
            && TemplateMatcher.decode("2,2,1,2,3") == null, "damaged saved pictures are ignored");

        // Make Honey: the picture is saved from the saved spot, then found where the button has moved to.
        MacroAccessibilityService s = start();
        setJoystick(s);
        setPicture(476, 1176);                 // the button around the saved spot (500, 1200)
        s.savePoint("conv", 500, 1200);
        Sim.runUntil(2000);
        check(TemplateMatcher.decode(new Config(s).tmplConvert) != null, "the Make Honey picture is saved from the screen");
        check(Sim.saw("Make Honey picture saved"), "the save says the picture was saved");
        clearPicture(476, 1176);
        setPicture(900, 1500);                 // the button has moved: its centre is (924, 1524)
        Config c = new Config(s);
        c.pattern = "Snake";
        c.bagX = 1000;
        c.bagY = 80;
        c.resetSteps = "100,100";
        c.respawnWait = 1;
        c.fullAction = 2;
        c.returnToField = true;
        c.field = "Clover";
        c.save();
        Sim.bagColor = 0xF70017;
        s.startMacro();
        Sim.runUntil(12000);
        Sim.bagColor = 0;
        Sim.runUntil(90000);
        check(countTaps(924, 1524) >= 1, "the convert tap lands on the picture where it is found");
        check(countTaps(500, 1200) == 0, "the saved spot is not used while the picture is on screen");

        // The picture is gone: the convert falls back to the last place the picture was found, and says so.
        int beforeFallback = countTaps(924, 1524);
        clearPicture(900, 1500);
        Sim.bagColor = 0xF70017;
        Sim.runUntil(Sim.now + 30000);
        Sim.bagColor = 0;
        Sim.runUntil(Sim.now + 90000);
        check(countTaps(924, 1524) > beforeFallback, "with no picture on screen, the last place it was found is used");
        check(Sim.saw("picture not on screen"), "the fallback says the picture was not on screen");

        // A picture that moved a little is found near the saved spot.
        s = start();
        setJoystick(s);
        setPicture(476, 1176);
        s.savePoint("conv", 500, 1200);
        Sim.runUntil(2000);
        clearPicture(476, 1176);
        setPicture(560, 1270);                 // centre (584, 1294), inside the window around (500, 1200)
        c = new Config(s);
        c.pattern = "Snake";
        c.bagX = 1000;
        c.bagY = 80;
        c.resetSteps = "100,100";
        c.respawnWait = 1;
        c.fullAction = 2;
        c.returnToField = true;
        c.field = "Clover";
        c.save();
        Sim.bagColor = 0xF70017;
        s.startMacro();
        Sim.runUntil(Sim.now + 25000);
        check(countTapsNear(584, 1294, 4) >= 1, "a picture that moved a little is found near the saved spot");

        // A picture far from the saved spot is still found, by the whole-screen search.
        s = start();
        setJoystick(s);
        setPicture(476, 1176);
        s.savePoint("conv", 500, 1200);
        Sim.runUntil(2000);
        clearPicture(476, 1176);
        setPicture(1000, 300);                 // centre (1024, 324): outside the window around (500, 1200)
        c = new Config(s);
        c.pattern = "Snake";
        c.bagX = 1000;
        c.bagY = 80;
        c.resetSteps = "100,100";
        c.respawnWait = 1;
        c.fullAction = 2;
        c.returnToField = true;
        c.field = "Clover";
        c.save();
        Sim.bagColor = 0xF70017;
        s.startMacro();
        Sim.runUntil(Sim.now + 25000);
        check(countTaps(1024, 324) >= 1, "a picture far from the saved spot is found by the whole-screen search");

        // The check button reports where the picture is, and that it is gone.
        s = start();
        setJoystick(s);
        setPicture(476, 1176);
        s.savePoint("conv", 500, 1200);
        Sim.runUntil(2000);
        s.checkConvertPicture(500);
        Sim.runUntil(Sim.now + 2000);
        check(MacroAccessibilityService.status.startsWith("Make Honey picture found at 500,1200"),
            "the check reports where the picture is: " + MacroAccessibilityService.status);
        clearPicture(476, 1176);
        s.checkConvertPicture(500);
        Sim.runUntil(Sim.now + 2000);
        check(MacroAccessibilityService.status.startsWith("Make Honey picture not found"),
            "the check reports when the picture is gone: " + MacroAccessibilityService.status);

        // A plain spot is refused, and nothing is saved.
        s = start();
        setJoystick(s);
        s.savePoint("conv", 500, 1200);        // the screen is all one colour here
        Sim.runUntil(2000);
        check(new Config(s).tmplConvert.length() == 0, "a plain spot is not saved as the picture");
        check(Sim.saw("too plain"), "the plain spot is refused with a message");
    }
}

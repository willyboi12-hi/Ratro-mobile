package com.natromobile;

import android.accessibilityservice.GestureDescription;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

/**
 * A fake clock, gesture log and screen. Everything the engine schedules runs here, in time order,
 * when a test calls runUntil(). Nothing waits on the real clock.
 */
public final class Sim {
    private Sim() {}

    /** One gesture the engine sent, with the time it was sent. */
    public static final class Gesture {
        public final long at;
        public final int x0, y0, x1, y1;
        public final long duration;
        public final boolean willContinue;

        Gesture(long at, GestureDescription.StrokeDescription s) {
            this.at = at;
            x0 = Math.round(s.x0); y0 = Math.round(s.y0);
            x1 = Math.round(s.x1); y1 = Math.round(s.y1);
            duration = s.duration;
            willContinue = s.willContinue;
        }

        @Override public String toString() {
            return "t=" + at + " (" + x0 + "," + y0 + ")->(" + x1 + "," + y1 + ") " + duration + "ms" + (willContinue ? " cont" : "");
        }
    }

    private static final class Task {
        final long at, seq;
        final Object owner;
        final Runnable run;
        Task(long at, long seq, Object owner, Runnable run) { this.at = at; this.seq = seq; this.owner = owner; this.run = run; }
    }

    private static final PriorityQueue<Task> queue = new PriorityQueue<Task>(16, new Comparator<Task>() {
        @Override public int compare(Task a, Task b) {
            if (a.at != b.at) return Long.compare(a.at, b.at);
            return Long.compare(a.seq, b.seq);
        }
    });
    private static long seq;

    public static long now;
    public static final List<Gesture> gestures = new ArrayList<Gesture>();
    public static final List<String> warnings = new ArrayList<String>();
    public static final List<String> toastLog = new ArrayList<String>();
    /** Set to false to make the next gestures be refused, like Android does when it is busy. */
    public static boolean acceptGestures = true;
    /** Set to true to cancel every gesture after it is sent. */
    public static boolean cancelAll = false;
    /** Set to true to make screenshots fail. */
    public static boolean failShots = false;
    /** When false, the engine skips human-like duration/stick jitter so tests get exact pixels. */
    public static boolean humanJitter = false;
    /** The color of every pixel. The bag reader only reads one pixel, so this is the bag color. */
    public static int bagColor = 0;
    /** Per-pixel overrides, for things like the disconnect spot. */
    private static final java.util.Map<String, Integer> pixels = new java.util.HashMap<String, Integer>();
    /** Intent data of every link the engine opened. */
    public static final List<String> launched = new ArrayList<String>();

    public static void reset() {
        queue.clear();
        seq = 0;
        now = 0;
        gestures.clear();
        warnings.clear();
        toastLog.clear();
        acceptGestures = true;
        cancelAll = false;
        failShots = false;
        humanJitter = false;
        bagColor = 0;
        pixels.clear();
        launched.clear();
        android.content.SharedPreferences.clearAll();
    }

    public static void post(Object owner, long delayMs, Runnable r) {
        queue.add(new Task(now + Math.max(0, delayMs), seq++, owner, r));
    }

    public static void removeAll(Object owner) {
        java.util.Iterator<Task> it = queue.iterator();
        while (it.hasNext()) if (it.next().owner == owner) it.remove();
    }

    /** Runs every scheduled task due at or before time t, in order, then moves the clock to t. */
    public static void runUntil(long t) {
        while (!queue.isEmpty() && queue.peek().at <= t) {
            Task task = queue.poll();
            now = task.at;
            task.run.run();
        }
        now = Math.max(now, t);
    }

    public static void setPixel(int x, int y, int color) { pixels.put(x + "," + y, color); }
    public static void clearPixel(int x, int y) { pixels.remove(x + "," + y); }
    public static int pixelAt(int x, int y) {
        Integer c = pixels.get(x + "," + y);
        return c == null ? bagColor : c;
    }

    public static void record(GestureDescription.StrokeDescription s) { gestures.add(new Gesture(now, s)); }
    public static void warn(String message) { warnings.add("t=" + now + " " + message); }
    public static void toast(String message) { toastLog.add(message); }

    public static boolean saw(String part) {
        for (String s : toastLog) if (s.contains(part)) return true;
        return false;
    }
}

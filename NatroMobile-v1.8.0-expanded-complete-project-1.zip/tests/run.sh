#!/usr/bin/env bash
# Runs the engine against the simulator in tests/. Needs only a JDK, no Android SDK, no network.
# The app's Android classes are replaced by the small stand-ins in tests/stubs.
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="build/tests"
rm -rf "$OUT"
mkdir -p "$OUT"
SOURCES=$(find tests/stubs tests/unit tests/sandbox app/src/main/java -name '*.java')
if command -v javac >/dev/null 2>&1; then
  javac -encoding UTF-8 -Xlint:none -d "$OUT" $SOURCES
else
  java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -nowarn -d "$OUT" $SOURCES
fi
java -cp "$OUT" com.natromobile.RunTests

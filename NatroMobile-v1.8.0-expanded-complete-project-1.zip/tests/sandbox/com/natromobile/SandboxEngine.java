package com.natromobile;

import java.util.PriorityQueue;
import java.util.concurrent.atomic.AtomicLong;

/** Deterministic, Android-independent simulation primitives for integration tests. */
public final class SandboxEngine {
    private SandboxEngine() {}

    public static final class Clock {
        private long now;
        private final PriorityQueue<Event> events = new PriorityQueue<>();
        private final AtomicLong sequence = new AtomicLong();
        public long now() { return now; }
        public void schedule(long delayMs, Runnable action) {
            if (delayMs < 0 || action == null) throw new IllegalArgumentException("invalid event");
            events.add(new Event(now + delayMs, sequence.getAndIncrement(), action));
        }
        public void advanceTo(long target) {
            if (target < now) throw new IllegalArgumentException("clock cannot move backwards");
            while (!events.isEmpty() && events.peek().at <= target) {
                Event e = events.remove(); now = e.at; e.action.run();
            }
            now = target;
        }
        public int queuedEvents() { return events.size(); }
        private static final class Event implements Comparable<Event> {
            final long at, sequence; final Runnable action;
            Event(long at, long sequence, Runnable action) { this.at=at; this.sequence=sequence; this.action=action; }
            public int compareTo(Event other) {
                int c = Long.compare(at, other.at);
                return c != 0 ? c : Long.compare(sequence, other.sequence);
            }
        }
    }

    public static final class Faults {
        private int screenshotFailures, gestureFailures;
        public void failNextScreenshots(int count) { screenshotFailures = Math.max(0, count); }
        public void failNextGestures(int count) { gestureFailures = Math.max(0, count); }
        public boolean screenshotSucceeds() {
            if (screenshotFailures == 0) return true;
            screenshotFailures--; return false;
        }
        public boolean gestureSucceeds() {
            if (gestureFailures == 0) return true;
            gestureFailures--; return false;
        }
    }

    public static final class Session {
        public enum State { STOPPED, RUNNING, PAUSED, ACCESSIBILITY_UNAVAILABLE, FAILED }
        private State state = State.STOPPED;
        private final Faults faults;
        public Session(Faults faults) { this.faults = faults; }
        public State state() { return state; }
        public void start() {
            if (state == State.ACCESSIBILITY_UNAVAILABLE || state == State.FAILED)
                throw new IllegalStateException("session cannot start in " + state);
            state = State.RUNNING;
        }
        public void pause() { if (state == State.RUNNING) state = State.PAUSED; }
        public void stop() { state = State.STOPPED; }
        public void accessibilityLost() { state = State.ACCESSIBILITY_UNAVAILABLE; }
        public boolean captureScreenshot() {
            requireRunning(); return faults.screenshotSucceeds();
        }
        public boolean submitGesture() {
            requireRunning(); return faults.gestureSucceeds();
        }
        private void requireRunning() {
            if (state != State.RUNNING) throw new IllegalStateException("automation is not running");
        }
    }
}

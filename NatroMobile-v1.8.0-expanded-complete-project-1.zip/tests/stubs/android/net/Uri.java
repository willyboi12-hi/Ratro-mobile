package android.net;

public class Uri {
    private final String value;
    private Uri(String value) { this.value = value; }
    public static Uri parse(String s) { return new Uri(s); }
    @Override public String toString() { return value; }
}

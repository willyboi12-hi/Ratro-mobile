package android.os;

import com.natromobile.Sim;

public class SystemClock {
    public static long uptimeMillis() { return Sim.now; }
}

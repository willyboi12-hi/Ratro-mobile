package android.os;

import com.natromobile.Sim;

/** Posts onto the simulated clock instead of a real message queue. */
public class Handler {
    public Handler(Looper looper) {}
    public boolean post(Runnable r) { return postDelayed(r, 0); }
    public boolean postDelayed(Runnable r, long delayMs) { Sim.post(this, delayMs, r); return true; }
    public void removeCallbacksAndMessages(Object token) { Sim.removeAll(this); }
}

package android.content;

import java.util.HashMap;
import java.util.Map;

/** In-memory preferences. Each name keeps its own map, like a real preferences file. */
public class SharedPreferences {
    private static final Map<String, Map<String, Object>> STORE = new HashMap<String, Map<String, Object>>();
    private final Map<String, Object> m;

    public SharedPreferences(String name) {
        Map<String, Object> existing = STORE.get(name);
        if (existing == null) { existing = new HashMap<String, Object>(); STORE.put(name, existing); }
        m = existing;
    }

    public static void clearAll() { STORE.clear(); }

    public int getInt(String k, int d) { Object v = m.get(k); return v == null ? d : (Integer) v; }
    public float getFloat(String k, float d) { Object v = m.get(k); return v == null ? d : (Float) v; }
    public String getString(String k, String d) { Object v = m.get(k); return v == null ? d : (String) v; }
    public boolean getBoolean(String k, boolean d) { Object v = m.get(k); return v == null ? d : (Boolean) v; }

    public Editor edit() { return new Editor(m); }

    public static final class Editor {
        private final Map<String, Object> target;
        private final Map<String, Object> pending = new HashMap<String, Object>();
        Editor(Map<String, Object> target) { this.target = target; }
        public Editor putInt(String k, int v) { pending.put(k, v); return this; }
        public Editor putFloat(String k, float v) { pending.put(k, v); return this; }
        public Editor putString(String k, String v) { pending.put(k, v); return this; }
        public Editor putBoolean(String k, boolean v) { pending.put(k, v); return this; }
        public void apply() { target.putAll(pending); }
    }
}

package android.content;

import android.content.res.Resources;
import android.view.WindowManager;
import java.util.concurrent.Executor;

public class Context {
    public static final String WINDOW_SERVICE = "window";
    public static final int MODE_PRIVATE = 0;
    private final Resources resources = new Resources();
    private final WindowManager windowManager = new WindowManager();

    public Object getSystemService(String name) { return WINDOW_SERVICE.equals(name) ? windowManager : null; }
    public SharedPreferences getSharedPreferences(String name, int mode) { return new SharedPreferences(name); }
    public Resources getResources() { return resources; }
    public void startActivity(Intent intent) { com.natromobile.Sim.launched.add(String.valueOf(intent.data)); }
    public Executor getMainExecutor() { return null; }
    public String getPackageName() { return "com.natromobile"; }
}

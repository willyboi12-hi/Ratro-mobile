package android.widget;

import android.content.Context;

public class ScrollView extends FrameLayout {
    public ScrollView(Context c) { super(c); }
    public void setFillViewport(boolean fill) {}
}

package android.widget;

import android.content.Context;
import com.natromobile.Sim;

public class Toast {
    public static final int LENGTH_SHORT = 0, LENGTH_LONG = 1;
    private final CharSequence text;
    private Toast(CharSequence text) { this.text = text; }
    public static Toast makeText(Context c, CharSequence text, int duration) { return new Toast(text); }
    public void show() { Sim.toast(String.valueOf(text)); }
}

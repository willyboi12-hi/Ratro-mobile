package android.view;

public class Gravity {
    public static final int TOP = 0x30, BOTTOM = 0x50, START = 0x00800003, END = 0x00800005;
    public static final int CENTER = 0x11, CENTER_HORIZONTAL = 0x01, CENTER_VERTICAL = 0x10;
}

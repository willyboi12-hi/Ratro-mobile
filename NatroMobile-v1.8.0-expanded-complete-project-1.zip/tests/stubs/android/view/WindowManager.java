package android.view;

/** Records nothing; overlays are not part of what the simulator checks. */
public class WindowManager {
    public void addView(View v, ViewGroup.LayoutParams lp) {}
    public void removeView(View v) {}
    public void updateViewLayout(View v, ViewGroup.LayoutParams lp) {}

    public static class LayoutParams extends ViewGroup.LayoutParams {
        public static final int TYPE_ACCESSIBILITY_OVERLAY = 2032;
        public static final int FLAG_NOT_FOCUSABLE = 0x8;
        public static final int FLAG_LAYOUT_IN_SCREEN = 0x100;
        public static final int FLAG_LAYOUT_NO_LIMITS = 0x200;
        public int x, y, gravity;
        public LayoutParams(int width, int height, int type, int flags, int format) { super(width, height); }
    }
}

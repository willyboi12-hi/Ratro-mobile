package android.view;

public class MotionEvent {
    public static final int ACTION_DOWN = 0, ACTION_UP = 1, ACTION_MOVE = 2;
    public int getActionMasked() { return ACTION_DOWN; }
    public float getRawX() { return 0f; }
    public float getRawY() { return 0f; }
}

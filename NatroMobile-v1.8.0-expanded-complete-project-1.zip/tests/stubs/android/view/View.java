package android.view;

import android.content.Context;
import android.graphics.drawable.Drawable;

/** Setters do nothing; the simulator only checks the engine's gestures, not what is drawn. */
public class View {
    public static final int VISIBLE = 0, INVISIBLE = 4, GONE = 8;

    public View() {}
    public View(Context c) {}

    public void setBackgroundColor(int color) {}
    public void setBackground(Drawable d) {}
    public void setVisibility(int v) {}
    public void setPadding(int l, int t, int r, int b) {}
    public void setMinHeight(int h) {}
    public void setMinimumHeight(int h) {}
    public void setMinWidth(int w) {}
    public void setMinimumWidth(int w) {}
    public void setClickable(boolean c) {}
    public void setGravity(int g) {}
    public void setTranslationX(float x) {}
    public void setTranslationY(float y) {}
    public void setOnClickListener(OnClickListener l) {}
    public void setOnTouchListener(OnTouchListener l) {}
    public boolean post(Runnable r) { r.run(); return true; }
    public int getScrollY() { return 0; }
    public void scrollTo(int x, int y) {}

    public interface OnClickListener { void onClick(View v); }
    public interface OnTouchListener { boolean onTouch(View v, MotionEvent e); }
}

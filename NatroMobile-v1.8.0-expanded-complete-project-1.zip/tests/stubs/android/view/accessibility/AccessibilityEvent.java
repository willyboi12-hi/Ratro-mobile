package android.view.accessibility;

/** Just the fields the engine reads: the package name and the event type. */
public class AccessibilityEvent {
    public static final int TYPE_WINDOW_STATE_CHANGED = 32;
    private final String packageName;
    public AccessibilityEvent() { this(""); }
    public AccessibilityEvent(String packageName) { this.packageName = packageName; }
    public CharSequence getPackageName() { return packageName; }
    public int getEventType() { return TYPE_WINDOW_STATE_CHANGED; }
}

package android.view;

public class Window {
    public void setStatusBarColor(int color) {}
}

# Sandbox guide

Run:
```bash
bash tests/run.sh
```

The script compiles the Android-independent test doubles, application Java sources, unit tests, and sandbox primitives, then runs `com.natromobile.RunTests`.

Sandbox primitives:
- `SandboxEngine.Clock`: deterministic event ordering and virtual time.
- `SandboxEngine.Faults`: inject a chosen number of screenshot or gesture failures.
- `SandboxEngine.Session`: checks safe state transitions and refuses actions when not running.

This sandbox does not emulate Android's actual accessibility framework, display compositor, screenshot permission flow, Roblox client, or device-specific gesture behavior. Use physical-device testing for those.

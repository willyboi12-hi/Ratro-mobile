# Architecture overview

## Existing application
`MainActivity` owns the user-facing configuration/dashboard. `MacroAccessibilityService` performs visible UI automation through Android accessibility APIs. Recognition and configuration logic are separated into `BagReader`, `TemplateMatcher`, `AutoSense`, `Config`, route and pattern classes.

## Task arbitration
`AutomationTaskCoordinator` is a deterministic priority arbiter. It selects one task category at a decision boundary; it does not execute gestures, create threads, or replace the service lifecycle. Emergency stop is latched until explicitly reset.

Priority: emergency stop → user interruption → accessibility unavailable → recovery → conversion → quest → farming.

## Sandbox
`tests/sandbox` contains Android-independent deterministic primitives:
- `Clock`: ordered virtual-time event scheduler.
- `Faults`: controlled screenshot and gesture failures.
- `Session`: a small state machine for running, paused, stopped, and accessibility-unavailable states.

The pre-existing `tests/stubs` provide minimal Android API stand-ins for JVM tests. This combination is not a full Android framework implementation.

## Data flow
User controls → MainActivity/configuration → accessibility service → screenshot/recognition and gesture APIs → task state/status → dashboard.

All screen actions must remain visible, user-authorized UI interactions. The project does not modify Roblox code or inspect hidden game memory.

# Changelog

## v1.8.0 source expansion
- Added `AutomationTaskCoordinator` with explicit priority arbitration and latched emergency stop.
- Added deterministic sandbox clock, fault injection, and session state model.
- Expanded JVM/sandbox tests from 739 to 750 passing checks.
- Added Gradle settings and Java 8 source compatibility.
- Expanded CI to run tests, lint, debug APK, and unsigned release APK tasks.
- Added audit, architecture, security, contribution, build, sandbox, device matrix, and production readiness documents.

## Limitations
Android build tasks and real-device validation have not been executed in this environment.

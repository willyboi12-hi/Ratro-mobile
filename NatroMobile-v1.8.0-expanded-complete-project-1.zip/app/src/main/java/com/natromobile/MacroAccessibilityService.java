package com.natromobile;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.HardwareBuffer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * The engine. Owns the floating bubble, the tap-to-save overlay, gestures, bag reading and convert.
 * MainActivity talks to it through the static instance.
 */
public class MacroAccessibilityService extends AccessibilityService {
    public static volatile MacroAccessibilityService instance;
    public static volatile String status = "Not connected yet.";
    public static volatile String bagLine = "Bag: not reading yet.";
    /** Tests set this true so moves are exact (no human jitter). */
    public static boolean disableJitterForTests = false;

    private static final long MOVE_MS = 40;
    /** Phase 6: small random factor so timers are not perfectly periodic. */
    private static double antiDetectJitter(double min, double max) {
        if (disableJitterForTests) return 1.0;
        return min + Math.random() * (max - min);
    }
    private static final long CHUNK_MS = 1500;
    private static final long BAG_POLL_MS = 1500;
    private static final long CONVERT_MAX_MS = 300000L;
    static final String ROBLOX_PACKAGE = "com.roblox.client";
    static final long LOST_MS = 8000L;   // how long Roblox may be off the screen before rejoining

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Handler bagHandler = new Handler(Looper.getMainLooper());

    private WindowManager wm;
    private Ui ui;

    // bubble: root holds the round button and, when opened, the menu card
    private LinearLayout root;
    private Button bubble;
    private LinearLayout card;
    private TextView cardStatus, cardBag;
    private Button cardToggle;
    private WindowManager.LayoutParams rootLp;
    private boolean bubbleShown, expanded;

    // tap-to-save overlay
    private View calibView;

    private Config cfg;
    private List<Patterns.Seg> plan = new ArrayList<Patterns.Seg>();
    private List<Patterns.Seg> patternPlan = new ArrayList<Patterns.Seg>();
    private int planIdx;
    private boolean loopPlan = true;
    private Runnable planDone;
    private boolean running, converting, polling, capturePending;
    private int token;
    private long runStartMs;
    private GestureDescription.StrokeDescription held;
    private float curX, curY;
    private boolean inFlight, releasePending;

    private final BagReader.Filter bagFilter = new BagReader.Filter(6);
    private volatile int bagFiltered = -1;
    private long lastFullAct;
    private boolean farming;      // true while the gather pattern is running (not while walking or converting)
    private long lastItemMs;      // when the timed item was last used
    private boolean itemPending;  // true right after farming starts, so the item is used at once
    private final long[] lastTripMs = {-1L, -1L};  // when each trip last ran this session, -1 = not yet
    // Phase 4 timed sequences
    private long lastBoosterMs, lastPlanterMs, lastQuestMs;
    private boolean boosterPending, planterPending, questPending;
    private int dcHits;           // readings in a row that matched the disconnect spot
    private long lostSinceMs = -1; // when another app first took the screen, or -1
    private boolean reconnecting;  // true while a rejoin is in progress; window events are ignored then
    // Fail-safes
    private long lastBagChangeMs;     // last time bag % actually moved
    private int lastBagSeen = -1;     // previous filtered bag value
    private long lastSelfCorrectMs;   // last forced self-correct
    private boolean failSafeRunning;  // true while a stuck/self-correct reset is in progress
    // Phase 2 scene
    private int lastScene = AutoSense.SCENE_UNKNOWN;
    private long lastHiveSceneMs;     // last time we saw AT_HIVE while supposed to be farming

    // ------------------------------------------------------------ lifecycle

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        ui = new Ui(this);
        say("Connected. Finish setup in the app, then press Start.");
        showBubble();
    }

    /**
     * Another app taking the screen starts a timer. Roblox coming back clears it. System UI and the app's own
     * windows are ignored. Only when the timer runs past LOST_MS does the app rejoin.
     */
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || !running || reconnecting || cfg == null || !cfg.watchRoblox) return;
        String pkg = event.getPackageName() == null ? "" : event.getPackageName().toString();
        if (pkg.length() == 0 || pkg.equals(getPackageName()) || pkg.equals("com.android.systemui")) return;
        if (pkg.equals(ROBLOX_PACKAGE)) { lostSinceMs = -1; return; }
        if (lostSinceMs < 0) {
            lostSinceMs = SystemClock.uptimeMillis();
            final int t = token;
            handler.postDelayed(new Runnable() { @Override public void run() { checkLost(t); } }, LOST_MS);
        }
    }

    private void checkLost(int t) {
        if (!running || t != token || reconnecting || lostSinceMs < 0) return;
        if (SystemClock.uptimeMillis() - lostSinceMs < LOST_MS) return;
        lostSinceMs = -1;
        reconnect(t);
    }

    @Override public void onInterrupt() { stopMacro(); }

    @Override public boolean onUnbind(Intent intent) {
        teardown();
        return super.onUnbind(intent);
    }

    @Override public void onDestroy() {
        teardown();
        super.onDestroy();
    }

    private void teardown() {
        stopMacro();
        polling = false;
        bagHandler.removeCallbacksAndMessages(null);
        closeCalib();
        hideBubble();
        instance = null;
    }

    private void say(String s) {
        status = s;
        updateCard();
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    public boolean isRunning() { return running; }

    // ------------------------------------------------------------ start / stop

    /** Used by the app's Start button: gives the user a few seconds to switch to Roblox. */
    public void startDelayed(final long ms) {
        say("Starting in " + (ms / 1000) + " seconds. Switch to Roblox now!");
        handler.postDelayed(new Runnable() { @Override public void run() { startMacro(); } }, ms);
    }

    /**
     * Takes a live screenshot, runs AutoSense, and writes confident spots into Config.
     * Call this while Roblox is on screen. Safe to call multiple times.
     */
    public void autoSenseSpots() {
        if (Build.VERSION.SDK_INT < 30) {
            say("Auto sense needs Android 11+");
            return;
        }
        if (capturePending) {
            say("Already capturing, wait a sec");
            return;
        }
        say("Capturing screen to sense spots... switch to Roblox if you haven't");
        capturePending = true;
        takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
            @Override public void onSuccess(ScreenshotResult r) {
                capturePending = false;
                applyAutoSense(r);
            }
            @Override public void onFailure(int errorCode) {
                capturePending = false;
                say("Auto sense screenshot failed (code " + errorCode + ")");
            }
        });
    }

    private void applyAutoSense(ScreenshotResult r) {
        HardwareBuffer hb = r.getHardwareBuffer();
        try {
            Bitmap hw = Bitmap.wrapHardwareBuffer(hb, r.getColorSpace());
            if (hw == null) {
                say("Auto sense: could not read buffer");
                return;
            }
            Bitmap sw = hw.copy(Bitmap.Config.ARGB_8888, false);
            hw.recycle();
            if (sw == null) {
                say("Auto sense: copy failed");
                return;
            }
            AutoSense.Result sense = AutoSense.sense(sw, screenW(), screenH());
            lastScene = sense.scene;
            sw.recycle();

            Config c = new Config(this);
            boolean changed = false;
            // Phase 2: trust strong vision matches even if a spot was already set
            if (sense.joyOk) {
                if (c.joyX <= 0 || c.joyY <= 0
                        || Math.abs(c.joyX - sense.joyX) + Math.abs(c.joyY - sense.joyY) > 40) {
                    c.joyX = sense.joyX;
                    c.joyY = sense.joyY;
                    changed = true;
                }
            }
            if (sense.bagOk) {
                if (c.bagX <= 0 || c.bagY <= 0
                        || Math.abs(c.bagX - sense.bagX) + Math.abs(c.bagY - sense.bagY) > 30) {
                    c.bagX = sense.bagX;
                    c.bagY = sense.bagY;
                    changed = true;
                }
            }
            if (sense.convOk) {
                if (c.convX <= 0 || c.convY <= 0
                        || Math.abs(c.convX - sense.convX) + Math.abs(c.convY - sense.convY) > 40) {
                    c.convX = sense.convX;
                    c.convY = sense.convY;
                    changed = true;
                }
            }
            if (c.radius < 70) {
                c.radius = Math.min(160, Math.max(90, (int) (screenW() * 0.12f)));
                changed = true;
            }
            String sceneWord = sense.scene == AutoSense.SCENE_AT_HIVE ? "at-hive"
                    : sense.scene == AutoSense.SCENE_ON_FIELD ? "on-field" : "unknown";
            if (changed) {
                c.save();
                say("Vision locked spots (" + sense.note + ", scene=" + sceneWord + ").");
            } else {
                say("Vision scan done (" + sense.note + ", scene=" + sceneWord + ").");
            }
        } catch (Exception e) {
            say("Auto sense error: " + e.getMessage());
        } finally {
            if (hb != null) hb.close();
        }
    }

    public void startMacro() {
        if (running) return;
        if (inFlight) { say("Still lifting the thumb. Try again in a moment."); return; }
        Config c = new Config(this);
        // First try ratio defaults, then the live screenshot sense will refine later if needed
        boolean filled = c.applySmartDefaults(screenW(), screenH());
        if (filled) say("Auto-set missing spots from screen size. Re-set any that feel off.");
        // Only kick a background auto-sense if spots were still missing after ratio defaults
        if (c.joyX <= 0 || c.bagX <= 0 || c.convX <= 0) {
            handler.postDelayed(new Runnable() {
                @Override public void run() {
                    if (!running) autoSenseSpots(); // don't overwrite mid-farm
                }
            }, 800);
        }
        if (c.joyX <= 0 || c.joyY <= 0) { say("Set the joystick spot first (Setup, step 2)."); return; }
        if (c.fullAction > 0 && (c.bagX <= 0 || c.bagY <= 0)) {
            say("Stop and Convert need the bag spot (Setup, step 3).");
            return;
        }
        if (c.fullAction == 2 && (c.convX <= 0 || c.convY <= 0)) {
            say("Convert needs the Make Honey button spot (Setup, step 4).");
            return;
        }
        cfg = c;
        if (cfg.moveSpeed < 1f) cfg.moveSpeed = 48f;
        // walkFirst comes from Config (default true). User toggle or tests can turn it off.
        patternPlan = Patterns.build(cfg.pattern, cfg.size, cfg.reps, cfg.invFB, cfg.invLR, cfg.facingCorner);
        plan = patternPlan;
        planIdx = 0;
        loopPlan = true;
        planDone = null;
        held = null;
        releasePending = false;
        converting = false;
        bagFilter.clear();
        bagFiltered = -1;
        running = true;
        token++;
        runStartMs = SystemClock.uptimeMillis();
        itemPending = true;  // timed sequences fire right away when farming starts
        lastTripMs[0] = -1L;
        lastTripMs[1] = -1L;
        boosterPending = true;
        planterPending = true;
        questPending = true;
        lastFullAct = SystemClock.uptimeMillis() - 20000;  // the bag cooldown does not block the first trigger
        reconnecting = false;
        lostSinceMs = -1;
        dcHits = 0;
        farming = false;
        startPolling();
        say("Going to " + cfg.field + " then farming " + cfg.pattern + " (" + cfg.size + ").");
        final int t = token;
        rotateCamera(cfg.rotateSwipes, t, new Runnable() {
            @Override public void run() { beginRun(t); }
        });
    }

    public void stopMacro() {
        boolean was = running;
        running = false;
        converting = false;
        farming = false;
        failSafeRunning = false;
        reconnecting = false;
        planDone = null;
        token++;
        handler.removeCallbacksAndMessages(null); // also cancels a pending delayed start
        if (inFlight) releasePending = true;      // lift the finger when the gesture in flight finishes
        else releaseFinger();
        if (was) say("Stopped.");
        else updateCard();
    }

    private void fail(int t, String msg) {
        if (t != token) return;
        running = false;
        converting = false;
        farming = false;
        failSafeRunning = false;
        planDone = null;
        token++;
        held = null; // Android already lifted the touch when it cancelled or rejected the gesture
        say("Stopped: " + msg);
    }

    // ------------------------------------------------------------ camera swipes

    private void rotateCamera(final int remaining, final int t, final Runnable done) {
        if (remaining == 0 || cfg.camX <= 0 || cfg.camY <= 0) { done.run(); return; }
        final int dir = remaining > 0 ? 1 : -1;
        Path p = new Path();
        p.moveTo(cfg.camX, cfg.camY);
        p.lineTo(clampX(cfg.camX + dir * cfg.swipeLen), cfg.camY);
        GestureDescription.StrokeDescription st = new GestureDescription.StrokeDescription(p, 0, 300);
        boolean ok = dispatchGesture(new GestureDescription.Builder().addStroke(st).build(),
            new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription d) { next(); }
                @Override public void onCancelled(GestureDescription d) { next(); }
                private void next() {
                    if (!running || t != token) return;
                    final int left = remaining - dir;
                    handler.postDelayed(new Runnable() {
                        @Override public void run() { rotateCamera(left, t, done); }
                    }, 250);
                }
            }, handler);
        if (!ok) fail(t, "Android refused the camera swipe. Check the camera spot.");
    }

    // ------------------------------------------------------------ walking

    private float clampX(float x) { return Math.max(1f, Math.min(screenW() - 1f, x)); }
    private float clampY(float y) { return Math.max(1f, Math.min(screenH() - 1f, y)); }
    private int screenW() { return getResources().getDisplayMetrics().widthPixels; }
    private int screenH() { return getResources().getDisplayMetrics().heightPixels; }

    /** Runs a list of segments. The caller must already have set running and token. */
    private void runPlan(List<Patterns.Seg> p, boolean loop, Runnable done) {
        plan = p;
        planIdx = 0;
        loopPlan = loop;
        planDone = done;
        nextSegment(token);
    }

    private void nextSegment(final int t) {
        if (!running || t != token) return;
        if (!converting && cfg.runMinutes > 0 && SystemClock.uptimeMillis() - runStartMs > cfg.runMinutes * 60000L) {
            stopMacro();
            say("Time is up. Stopped.");
            return;
        }
        if (farming && !converting) {
            // Smart quest: vision-gated before blind timed quest taps
            if (questDue() && cfg.questSmart && Build.VERSION.SDK_INT >= 30) {
                trySmartQuest(t);
                return;
            }
            // Phase 4: item / booster / planter / (dumb) quest between gather steps
            final List<int[]> timed = nextTimedTaps();
            if (timed != null) {
                releaseFinger();
                long gap = (!disableJitterForTests && cfg != null && cfg.humanMode) ? 150 : 60;
                handler.postDelayed(new Runnable() {
                    @Override public void run() {
                        runTaps(timed, 0, t, new Runnable() { @Override public void run() { nextSegment(t); } });
                    }
                }, gap);
                return;
            }
        }
        if (planIdx >= plan.size()) {
            if (!loopPlan) {
                releaseFinger();
                final Runnable done = planDone;
                planDone = null;
                if (done != null) handler.postDelayed(done, 500);
                return;
            }
            planIdx = 0; // repeat the pattern until stopped
        }
        final boolean human = !disableJitterForTests && cfg != null && cfg.humanMode;
        final int level = (cfg == null) ? 1 : Math.max(0, Math.min(2, cfg.humanLevel));

        // Occasional short human pause (kept brief so farming stays fast)
        if (human && farming && Math.random() < (0.02 + level * 0.015)) {
            long pause = 80 + (long) (Math.random() * (120 + level * 150));
            releaseFinger();
            handler.postDelayed(new Runnable() {
                @Override public void run() {
                    if (!running || t != token) return;
                    nextSegment(t);
                }
            }, pause);
            return;
        }

        final Patterns.Seg s = plan.get(planIdx++);
        if (s.rotate != 0) {
            // A camera turn (Natro's RotLeft / RotRight): swipe the camera the same number of times.
            releaseFinger();
            rotateCamera(s.rotate, t, new Runnable() { @Override public void run() { nextSegment(t); } });
            return;
        }
        // Fast-human: small duration wobble so it is not robotic but still quick
        double jMin = human ? (level == 0 ? 0.96 : level == 1 ? 0.93 : 0.90) : 1.0;
        double jSpan = human ? (level == 0 ? 0.06 : level == 1 ? 0.10 : 0.14) : 0.0;
        double jitter = jMin + Math.random() * jSpan;
        final long durMs = Math.max(100L, (long) (s.durationMs(cfg.moveSpeed) * jitter));
        final long segStart = SystemClock.uptimeMillis();

        if (s.isWait()) {
            long extra = human ? (long) (Math.random() * (40 + level * 40)) : 0;
            releaseFinger();
            handler.postDelayed(new Runnable() { @Override public void run() { nextSegment(t); } }, durMs + extra);
            return;
        }

        float len = (float) Math.sqrt(s.dx * s.dx + s.dy * s.dy);
        if (len < 0.001f) {
            // Degenerate segment - treat as a short wait instead of dividing by zero
            releaseFinger();
            handler.postDelayed(new Runnable() { @Override public void run() { nextSegment(t); } }, Math.max(100L, durMs));
            return;
        }
        // Light stick drift (human but still accurate)
        float driftAmp = human ? (2f + level * 2f) : 0f;
        float drift = (float) ((Math.random() - 0.5) * driftAmp);
        float drift2 = (float) ((Math.random() - 0.5) * driftAmp * 0.7f);
        final float tx = clampX(cfg.joyX + s.dx / len * cfg.radius + drift);
        final float ty = clampY(cfg.joyY + s.dy / len * cfg.radius + drift2);

        // Stick slide: exact in tests, fast otherwise, slight human variance
        long moveMs = 32;
        if (disableJitterForTests) moveMs = 60;
        else if (human) moveMs = 34 + (long) (Math.random() * (8 + level * 6));

        Path move = new Path();
        GestureDescription.StrokeDescription st;
        if (held == null) {
            move.moveTo(cfg.joyX, cfg.joyY);
            move.lineTo(tx, ty);
            st = new GestureDescription.StrokeDescription(move, 0, moveMs, true);
        } else {
            move.moveTo(curX, curY);
            move.lineTo(tx, ty);
            st = held.continueStroke(move, 0, moveMs, true);
        }
        send(st, t, new Runnable() {
            @Override public void run() {
                curX = tx;
                curY = ty;
                // Tiny settle before hold so it does not look frame-perfect
                final long settle = human ? (long) (Math.random() * (12 + level * 10)) : 0;
                if (settle <= 0) {
                    hold(t, segStart + durMs, new Runnable() {
                        @Override public void run() { nextSegment(t); }
                    });
                    return;
                }
                handler.postDelayed(new Runnable() {
                    @Override public void run() {
                        if (!running || t != token) return;
                        // settle already waited; hold for the remaining segment time
                        hold(t, SystemClock.uptimeMillis() + Math.max(50L, durMs - settle), new Runnable() {
                            @Override public void run() { nextSegment(t); }
                        });
                    }
                }, settle);
            }
        });
    }

    /** Keeps the thumb still at (curX, curY) until the absolute time endMs, in short chained chunks. */
    private void hold(final int t, final long endMs, final Runnable then) {
        if (!running || t != token) return;
        long remaining = endMs - SystemClock.uptimeMillis();
        if (remaining <= 20) { then.run(); return; }
        long chunk = Math.min(remaining, CHUNK_MS);
        Path p = new Path();
        p.moveTo(curX, curY);
        GestureDescription.StrokeDescription st = held.continueStroke(p, 0, chunk, true);
        send(st, t, new Runnable() { @Override public void run() { hold(t, endMs, then); } });
    }

    private void send(final GestureDescription.StrokeDescription st, final int t, final Runnable onDone) {
        inFlight = true;
        boolean ok = dispatchGesture(new GestureDescription.Builder().addStroke(st).build(),
            new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription d) {
                    inFlight = false;
                    held = st;
                    if (releasePending) { releasePending = false; releaseFinger(); return; }
                    if (running && t == token) onDone.run();
                }
                @Override public void onCancelled(GestureDescription d) {
                    inFlight = false;
                    held = null;
                    releasePending = false;
                    fail(t, "Android cancelled a touch (another touch or a screen change).");
                }
            }, handler);
        if (!ok) {
            inFlight = false;
            fail(t, "Android refused a touch. Check the joystick spot.");
        }
    }

    /** Lifts the thumb if it is down. */
    private void releaseFinger() {
        if (held == null) return;
        Path p = new Path();
        p.moveTo(curX, curY);
        GestureDescription.StrokeDescription end = held.continueStroke(p, 0, 20, false);
        held = null;
        inFlight = true;
        boolean ok = dispatchGesture(new GestureDescription.Builder().addStroke(end).build(),
            new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription d) { inFlight = false; }
                @Override public void onCancelled(GestureDescription d) { inFlight = false; }
            }, handler);
        if (!ok) inFlight = false;
    }

    /** Quick tap at a saved spot, used for the reset steps and the convert button. */
    private void tapAt(final int x, final int y, final int t, final Runnable next) {
        Path p = new Path();
        p.moveTo(x, y);
        boolean ok = dispatchGesture(new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(p, 0, 60)).build(),
            new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription d) { if (running && t == token) next.run(); }
                @Override public void onCancelled(GestureDescription d) { if (running && t == token) next.run(); }
            }, handler);
        if (!ok) fail(t, "Android refused a tap at " + x + ", " + y + ".");
    }

    /** Test the full walk-to-field path without starting the gather loop. */
    public void testWalkToField(final long delayMs) {
        say("Walk test starts in " + (delayMs / 1000) + " seconds. Switch to Roblox now.");
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (running) { say("Stop farming before testing."); return; }
                Config c = new Config(MacroAccessibilityService.this);
                c.applySmartDefaults(screenW(), screenH());
                if (c.joyX <= 0 || c.joyY <= 0) {
                    say("Need a joystick spot first.");
                    return;
                }
                cfg = c;
                running = true;
                token++;
                final int t = token;
                farming = false;
                converting = false;
                failSafeRunning = false;
                say("Testing walk to " + cfg.field + "...");
                goToField(t, true, new Runnable() {
                    @Override public void run() {
                        running = false;
                        say("Walk test finished. You should be at " + cfg.field + ".");
                    }
                });
            }
        }, delayMs);
    }

    /** Joystick test from the Advanced screen. It starts after a delay so the user can switch to Roblox. */
    public void testMove(final long delayMs) {
        Config c = new Config(this);
        if (c.joyX <= 0 || c.joyY <= 0) { say("Set the joystick spot first (Setup, step 2)."); return; }
        say("Test starts in " + (delayMs / 1000) + " seconds. Switch to Roblox now.");
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (running) { say("Stop farming before testing."); return; }
                cfg = new Config(MacroAccessibilityService.this);
                running = true;
                converting = false;
                token++;
                final int t = token;
                runStartMs = SystemClock.uptimeMillis();
                List<Patterns.Seg> one = new ArrayList<Patterns.Seg>();
                one.add(new Patterns.Seg(1, 0, 0, 1.0));
                say("Testing: the thumb moves right for one second.");
                runPlan(one, false, new Runnable() {
                    @Override public void run() {
                        if (t != token) return;
                        running = false;
                        token++;
                        say("Test finished.");
                    }
                });
            }
        }, delayMs);
    }

    /** Walks a known 10 tiles to the right, so the walk speed can be checked against what the character covers. */
    public void walkCheck(final long delayMs) {
        Config c = new Config(this);
        if (c.joyX <= 0 || c.joyY <= 0) { say("Set the joystick spot first (Setup, step 2)."); return; }
        say("Walk check " + (delayMs >= 1000 ? "starts in " + (delayMs / 1000) + " seconds" : "starts now")
            + ". Switch to Roblox and find a spot you can measure from.");
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (running) { say("Stop farming before the walk check."); return; }
                cfg = new Config(MacroAccessibilityService.this);
                running = true;
                converting = false;
                farming = false;
                token++;
                final int t = token;
                runStartMs = SystemClock.uptimeMillis();
                List<Patterns.Seg> walk = new ArrayList<Patterns.Seg>();
                walk.add(new Patterns.Seg(1, 0, Calibration.EXPECTED_TILES, -1));
                say("Walk check: walking 10 tiles to the right.");
                runPlan(walk, false, new Runnable() {
                    @Override public void run() {
                        if (t != token) return;
                        running = false;
                        token++;
                        say("Walk check finished. Enter how far it went, in tiles, under Advanced.");
                    }
                });
            }
        }, delayMs);
    }

    private boolean questDue() {
        if (cfg == null || cfg.questMinutes <= 0 || cfg.questTaps().isEmpty()) return false;
        return questPending || SystemClock.uptimeMillis() - lastQuestMs >= (long) (cfg.questMinutes * 60000L * antiDetectJitter(0.88, 1.12));
    }

    /**
     * Vision-gated quest: screenshot, look for claim-colored buttons.
     * If found, tap claim then saved quest taps. If not, short backoff without full interval burn.
     */
    /**
     * Green = quest finished / Turn In ready.
     * Grey = still incomplete (e.g. pollen not done) → ignore.
     * Flow when green found: tap green Turn In → saved quest taps → go to NPC (questNpc taps) for next quest.
     */
    private void trySmartQuest(final int t) {
        if (capturePending) {
            handler.postDelayed(new Runnable() {
                @Override public void run() { nextSegment(t); }
            }, 200);
            return;
        }
        releaseFinger();
        capturePending = true;
        say("Smart quest: looking for green Complete rows...");
        takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
            @Override public void onSuccess(ScreenshotResult r) {
                capturePending = false;
                if (!running || t != token || !farming) return;
                boolean greenReady = false;
                int cx = 0, cy = 0;
                HardwareBuffer hb = r.getHardwareBuffer();
                try {
                    Bitmap hw = Bitmap.wrapHardwareBuffer(hb, r.getColorSpace());
                    if (hw != null) {
                        Bitmap sw = hw.copy(Bitmap.Config.ARGB_8888, false);
                        hw.recycle();
                        if (sw != null) {
                            AutoSense.Result q = AutoSense.questProbe(sw);
                            sw.recycle();
                            // Only act on true green turn-in — never grey incomplete
                            if (q.claimOk) {
                                greenReady = true;
                                cx = q.claimX;
                                cy = q.claimY;
                            }
                        }
                    }
                } catch (Exception ignored) {
                } finally {
                    if (hb != null) hb.close();
                }

                if (greenReady) {
                    lastQuestMs = SystemClock.uptimeMillis();
                    questPending = false;
                    final List<int[]> turnIn = new java.util.ArrayList<int[]>();
                    if (cx > 0 && cy > 0) turnIn.add(new int[]{cx, cy});
                    turnIn.addAll(cfg.questTaps());
                    say("Green Complete found. Turning in then talking to NPC...");
                    runTaps(turnIn, 0, t, new Runnable() {
                        @Override public void run() {
                            if (!running || t != token) return;
                            List<int[]> npc = cfg.questNpcTaps();
                            if (npc.isEmpty()) {
                                say("Turn-in done. No NPC taps saved for next quest.");
                                nextSegment(t);
                                return;
                            }
                            // Short pause so dialog / camera can settle before NPC
                            handler.postDelayed(new Runnable() {
                                @Override public void run() {
                                    if (!running || t != token) return;
                                    say("Going to quest NPC for next quest...");
                                    runTaps(cfg.questNpcTaps(), 0, t, new Runnable() {
                                        @Override public void run() { nextSegment(t); }
                                    });
                                }
                            }, 900);
                        }
                    });
                } else {
                    // Incomplete (grey) or no UI — soft retry, do not burn full interval
                    lastQuestMs = SystemClock.uptimeMillis() - Math.max(0, cfg.questMinutes * 60000L - 25000L);
                    questPending = false;
                    say("No green Complete (red/incomplete or closed). Retry soon.");
                    handler.postDelayed(new Runnable() {
                        @Override public void run() { nextSegment(t); }
                    }, 300);
                }
            }
            @Override public void onFailure(int errorCode) {
                capturePending = false;
                if (!running || t != token) return;
                lastQuestMs = SystemClock.uptimeMillis();
                questPending = false;
                say("Quest scan failed. Skipping this cycle.");
                handler.postDelayed(new Runnable() {
                    @Override public void run() { nextSegment(t); }
                }, 300);
            }
        });
    }

    /**
     * Picks the highest-priority timed sequence that is due.
     * Order: quest (dumb mode) → booster → planter → generic item.
     * Smart quest is handled separately in trySmartQuest.
     */
    private List<int[]> nextTimedTaps() {
        if (cfg == null) return null;
        long now = SystemClock.uptimeMillis();
        // Dumb quest only when smart mode is off
        if (!cfg.questSmart && cfg.questMinutes > 0 && !cfg.questTaps().isEmpty()
                && (questPending || now - lastQuestMs >= (long) (cfg.questMinutes * 60000L * antiDetectJitter(0.88, 1.12)))) {
            lastQuestMs = now;
            questPending = false;
            say("Quest taps...");
            return cfg.questTaps();
        }
        if (cfg.boosterMinutes > 0 && !cfg.boosterTaps().isEmpty()
                && (boosterPending || now - lastBoosterMs >= (long) (cfg.boosterMinutes * 60000L * antiDetectJitter(0.88, 1.12)))) {
            lastBoosterMs = now;
            boosterPending = false;
            say("Booster taps...");
            return cfg.boosterTaps();
        }
        if (cfg.planterMinutes > 0 && !cfg.planterTaps().isEmpty()
                && (planterPending || now - lastPlanterMs >= (long) (cfg.planterMinutes * 60000L * antiDetectJitter(0.88, 1.12)))) {
            lastPlanterMs = now;
            planterPending = false;
            say("Planter taps...");
            return cfg.planterTaps();
        }
        if (cfg.itemMinutes > 0 && !cfg.itemTaps().isEmpty()
                && (itemPending || now - lastItemMs >= (long) (cfg.itemMinutes * 60000L * antiDetectJitter(0.88, 1.12)))) {
            lastItemMs = now;
            itemPending = false;
            say("Item taps...");
            return cfg.itemTaps();
        }
        return null;
    }

    /** Runs the saved item taps once, for checking them from the Advanced screen. */
    public void testItem(final long delayMs) {
        Config c = new Config(this);
        if (c.itemTaps().isEmpty()) { say("Add the item taps first (Setup)."); return; }
        say("Item test starts in " + (delayMs / 1000) + " seconds. Switch to Roblox now.");
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (running) { say("Stop farming before testing."); return; }
                cfg = new Config(MacroAccessibilityService.this);
                running = true;
                converting = false;
                farming = false;
                token++;
                final int t = token;
                runStartMs = SystemClock.uptimeMillis();
                say("Testing the item taps.");
                runTaps(cfg.itemTaps(), 0, t, new Runnable() {
                    @Override public void run() {
                        if (t != token) return;
                        running = false;
                        token++;
                        say("Item test finished.");
                    }
                });
            }
        }, delayMs);
    }

    // ------------------------------------------------------------ bag reading (screenshots)

    private void startPolling() {
        if (polling) return;
        polling = true;
        bagHandler.post(bagPoll);
    }

    private final Runnable bagPoll = new Runnable() {
        @Override public void run() {
            if (!polling) return;
            if (!running && !expanded) { polling = false; return; }
            captureBag();
            bagHandler.postDelayed(this, BAG_POLL_MS);
        }
    };

    private void captureBag() {
        if (capturePending) return;
        final Config c = new Config(this);
        boolean bag = c.bagX > 0 && c.bagY > 0;
        boolean dc = c.dcX > 0 && c.dcY > 0;
        if (!bag && !dc) { setBagLabel("Bag: set the bag spot in Setup"); polling = false; return; }
        if (Build.VERSION.SDK_INT < 30) { setBagLabel("Bag reading needs Android 11 or newer"); polling = false; return; }
        capturePending = true;
        takeShot(c);
    }

    private void takeShot(final Config c) {
        final int t = token;
        takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
            @Override public void onSuccess(ScreenshotResult r) {
                capturePending = false;
                readBag(r, c, t);
            }
            @Override public void onFailure(int errorCode) {
                capturePending = false;
                setBagLabel("Bag: screenshot failed (code " + errorCode + ")");
            }
        });
    }

    private void readBag(ScreenshotResult r, Config c, int t) {
        int pct = -1, dcColor = -1;
        boolean bag = c.bagX > 0 && c.bagY > 0;
        boolean dc = c.dcX > 0 && c.dcY > 0;
        HardwareBuffer hb = r.getHardwareBuffer();
        try {
            Bitmap hw = Bitmap.wrapHardwareBuffer(hb, r.getColorSpace());
            if (hw != null) {
                Bitmap sw = hw.copy(Bitmap.Config.ARGB_8888, false);
                hw.recycle();
                if (sw != null) {
                    if (bag) pct = BagReader.percentFromColor(pixel(sw, c.bagX, c.bagY));
                    if (dc) dcColor = regionAverage(sw, c.dcX, c.dcY);
                    // Phase 2: classify hive vs field from the same frame
                    lastScene = AutoSense.sceneOnly(sw);
                    if (farming && !converting && !failSafeRunning
                            && lastScene == AutoSense.SCENE_AT_HIVE) {
                        if (lastHiveSceneMs <= 0) lastHiveSceneMs = SystemClock.uptimeMillis();
                    } else {
                        lastHiveSceneMs = 0;
                    }
                    sw.recycle();
                }
            }
        } catch (Exception e) {
            pct = -1;
            dcColor = -1;
        } finally {
            if (hb != null) hb.close();
        }
        if (pct >= 0) onBagReading(pct, c);
        if (dcColor >= 0) checkDisconnect(dcColor, c, t);
    }

    /** Average color of a 7x7 block centered on (x, y). One stray pixel or a small cursor barely moves it. */
    private static int regionAverage(Bitmap b, int x, int y) {
        long r = 0, g = 0, bl = 0;
        int n = 0;
        for (int dy = -3; dy <= 3; dy++) {
            for (int dx = -3; dx <= 3; dx++) {
                int c = pixel(b, x + dx, y + dy);
                r += (c >> 16) & 255;
                g += (c >> 8) & 255;
                bl += c & 255;
                n++;
            }
        }
        return (int) (((r / n) << 16) | ((g / n) << 8) | (bl / n));
    }

    private static String hex(int c) { return String.format("#%06X", c & 0xFFFFFF); }

    private static int pixel(Bitmap b, int x, int y) {
        int px = Math.max(0, Math.min(b.getWidth() - 1, x));
        int py = Math.max(0, Math.min(b.getHeight() - 1, y));
        return b.getPixel(px, py);
    }

    /** Three readings in a row that match the saved disconnect color mean Roblox dropped us. */
    private void checkDisconnect(int color, Config c, int t) {
        if (!running || !farming || t != token) { dcHits = 0; return; }
        dcHits = similar(color, c.dcColor) ? dcHits + 1 : 0;
        if (dcHits >= 3) {
            dcHits = 0;
            reconnect(t);
        }
    }

    private static boolean similar(int a, int b) {
        return Math.abs(((a >> 16) & 255) - ((b >> 16) & 255)) <= 24
            && Math.abs(((a >> 8) & 255) - ((b >> 8) & 255)) <= 24
            && Math.abs((a & 255) - (b & 255)) <= 24;
    }

    private void setBagLabel(String s) {
        bagLine = s;
        if (cardBag != null) cardBag.setText(s);
    }

    private void onBagReading(int pct, Config c) {
        bagFiltered = bagFilter.add(pct);
        String sceneTag = "";
        if (lastScene == AutoSense.SCENE_AT_HIVE) sceneTag = " | hive";
        else if (lastScene == AutoSense.SCENE_ON_FIELD) sceneTag = " | field";
        setBagLabel("Bag: " + bagFiltered + "% full" + sceneTag);
        // Track real bag movement for stuck detection
        if (bagFiltered != lastBagSeen) {
            lastBagSeen = bagFiltered;
            lastBagChangeMs = SystemClock.uptimeMillis();
        }
        if (!running || converting || !farming || failSafeRunning || c.fullAction == 0) return;
        if (bagFiltered < c.fullPercent) return;
        if (SystemClock.uptimeMillis() - lastFullAct < 20000) return;
        lastFullAct = SystemClock.uptimeMillis();
        if (c.fullAction == 1) {
            stopMacro();
            say("Bag is " + bagFiltered + "% full. Stopped.");
        } else {
            startConvert();
        }
    }

    /** Opens the private server link, waits for the game to load, walks back to the field, and farms again. */
    public void rejoinNow() {
        if (!running) { say("Start farming first, then test the rejoin."); return; }
        reconnect(token);
    }

    /**
     * Phase 3 panic: "I'm lost".
     * If farming: hard realign (reset + ramp + field route + resume).
     * If a private link exists and user is fully lost: optional rejoin path via reconnect.
     * If not running: start a recovery walk to the field after a short delay.
     */
    public void imLost() {
        Config c = new Config(this);
        c.applySmartDefaults(screenW(), screenH());
        if (c.joyX <= 0 || c.joyY <= 0) {
            say("Set joystick (or run Vision scan) before I'm lost.");
            return;
        }
        cfg = c;
        if (running && !failSafeRunning) {
            say("I'm lost: forcing realign to " + cfg.field + ".");
            forceRealign(token, "im-lost");
            return;
        }
        if (running) {
            say("Already realigning. Wait a sec.");
            return;
        }
        // Not running - start a one-shot recovery walk then farm
        // Bump token so any previous delayed recovery is ignored
        token++;
        final int recoverToken = token;
        say("I'm lost recovery in 3s. Switch to Roblox.");
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (running || recoverToken != token) return;
                if (cfg.moveSpeed < 1f) cfg.moveSpeed = 48f;
                patternPlan = Patterns.build(cfg.pattern, cfg.size, cfg.reps, cfg.invFB, cfg.invLR, cfg.facingCorner);
                plan = patternPlan;
                planIdx = 0;
                loopPlan = true;
                planDone = null;
                held = null;
                releasePending = false;
                converting = false;
                farming = false;
                failSafeRunning = false;
                bagFilter.clear();
                bagFiltered = -1;
                running = true;
                token++;
                runStartMs = SystemClock.uptimeMillis();
                itemPending = true;
                boosterPending = true;
                planterPending = true;
                questPending = true;
                lastFullAct = SystemClock.uptimeMillis() - 20000;
                reconnecting = false;
                lostSinceMs = -1;
                dcHits = 0;
                lastHiveSceneMs = 0;
                startPolling();
                final int t = token;
                say("Recovery: reset and walk to " + cfg.field + ".");
                goToField(t, true, farmThen(t));
            }
        }, 3000);
    }

    private void reconnect(int oldToken) {
        if (!running || oldToken != token) return;
        final Config c = cfg;
        if (c.privateLink == null || c.privateLink.trim().length() == 0) {
            fail(oldToken, "Roblox disconnected, and there is no private server link (Advanced).");
            return;
        }
        farming = false;
        converting = false;
        token++;
        final int t = token;
        handler.removeCallbacksAndMessages(null);   // drop any pending pattern steps
        reconnecting = true;
        lostSinceMs = -1;
        if (inFlight) releasePending = true;
        else releaseFinger();
        say("Disconnected. Rejoining your private server...");
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(RobloxLink.toRobloxUri(c.privateLink)));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (!running || t != token) return;
                reconnecting = false;
                goToField(t, true, farmThen(t));
            }
        }, Math.max(5, c.rejoinSec) * 1000L);
    }

    /** Reads the color at the saved disconnect spot from a screenshot, after the overlay has closed. */
    /** Reads the color at the saved disconnect spot from a screenshot, after the overlay has closed. */
    void sampleDisconnectColor() {
        final Config c = new Config(this);
        takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
            @Override public void onSuccess(ScreenshotResult r) {
                int col = readRegion(r, c.dcX, c.dcY);
                if (col >= 0) {
                    Config saved = new Config(MacroAccessibilityService.this);
                    saved.dcColor = col;
                    saved.save();
                    say("Disconnect spot ready (" + hex(col) + "). It is checked while farming.");
                } else {
                    say("Could not read the color there. Set the disconnect spot again.");
                }
            }
            @Override public void onFailure(int errorCode) {
                say("Could not read the screen (code " + errorCode + ").");
            }
        });
    }

    /** Says whether the saved disconnect spot matches the screen now, so a mismatch can be checked on the phone. */
    public void checkDisconnectSpot(final long delayMs) {
        final Config c = new Config(this);
        if (c.dcX <= 0 || c.dcY <= 0) { say("Set the disconnect spot first (Setup, step 8)."); return; }
        say("Checking the disconnect spot " + (delayMs >= 1000 ? "in " + (delayMs / 1000) + " seconds" : "now")
            + ". Switch to Roblox's disconnect screen.");
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
                    @Override public void onSuccess(ScreenshotResult r) {
                        int col = readRegion(r, c.dcX, c.dcY);
                        if (col < 0) { say("Could not read the screen."); return; }
                        boolean match = similar(col, c.dcColor);
                        say((match ? "Matches" : "Does not match") + ". The screen now is " + hex(col)
                            + ", saved " + hex(c.dcColor) + ".");
                    }
                    @Override public void onFailure(int errorCode) {
                        say("Could not read the screen (code " + errorCode + ").");
                    }
                });
            }
        }, delayMs);
    }

    /** Average color around (x, y) from one screenshot, or -1 if the screenshot could not be read. */
    private static int readRegion(ScreenshotResult r, int x, int y) {
        int col = -1;
        HardwareBuffer hb = r.getHardwareBuffer();
        try {
            Bitmap hw = Bitmap.wrapHardwareBuffer(hb, r.getColorSpace());
            if (hw != null) {
                Bitmap sw = hw.copy(Bitmap.Config.ARGB_8888, false);
                hw.recycle();
                if (sw != null) {
                    col = regionAverage(sw, x, y);
                    sw.recycle();
                }
            }
        } catch (Exception e) {
            col = -1;
        } finally {
            if (hb != null) hb.close();
        }
        return col;
    }

    // ------------------------------------------------------------ convert at the hive

    /** Reset with the saved taps, walk to the hive pad, tap Make Honey, wait for the bag to empty. */
    private void startConvert() {
        converting = true;
        farming = false;
        failSafeRunning = false;
        handler.removeCallbacksAndMessages(null);
        token++;
        final int t = token;
        say("Bag is " + bagFiltered + "% full. Converting at the hive.");
        bagFilter.clear();
        bagFiltered = -1;
        lastBagChangeMs = SystemClock.uptimeMillis();
        if (inFlight) releasePending = true;
        else releaseFinger();
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                List<int[]> resets = cfg.resetTaps();
                if (resets.isEmpty()) {
                    // No reset taps - go straight to ramp/hive walk
                    afterReset(t);
                } else {
                    runTaps(resets, 0, t, new Runnable() { @Override public void run() { afterReset(t); } });
                }
            }
        }, 600);
    }

    private void runTaps(final List<int[]> taps, final int i, final int t, final Runnable done) {
        if (!running || t != token) return;
        if (i >= taps.size()) { done.run(); return; }
        int[] pt = taps.get(i);
        // Phase 5: small random offset on tap so it is not the same pixel every time
        int ox = 0, oy = 0;
        if (!disableJitterForTests && cfg != null && cfg.humanMode) {
            int amp = 2 + Math.max(0, Math.min(2, cfg.humanLevel)) * 2;
            ox = (int) ((Math.random() - 0.5) * amp * 2);
            oy = (int) ((Math.random() - 0.5) * amp * 2);
        }
        final int tx = Math.max(1, pt[0] + ox);
        final int ty = Math.max(1, pt[1] + oy);
        long gap = 150; // fast farming default
        if (!disableJitterForTests && cfg != null && cfg.humanMode) {
            int level = Math.max(0, Math.min(2, cfg.humanLevel));
            gap = 160 + (long) (Math.random() * (80 + level * 60)); // human but still quick
        }
        final long gapFinal = gap;
        tapAt(tx, ty, t, new Runnable() {
            @Override public void run() {
                handler.postDelayed(new Runnable() {
                    @Override public void run() { runTaps(taps, i + 1, t, done); }
                }, gapFinal);
            }
        });
    }

    private void afterReset(final int t) {
        rampWalk(t, new Runnable() { @Override public void run() { atHive(t); } });
    }

    /** Natro's nm_gotoRamp walk, in tiles: 5 forward, then right by 9.2 x slot - 4. Runs after the respawn wait. */
    private void rampWalk(final int t, final Runnable next) {
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (!running || t != token) return;
                int slot = Math.max(1, Math.min(6, cfg.hiveSlot));
                List<Patterns.Seg> walk = new ArrayList<Patterns.Seg>();
                walk.add(new Patterns.Seg(0, -1, 5.0, -1));
                walk.add(new Patterns.Seg(1, 0, 9.2 * slot - 4, -1));
                runPlan(walk, false, next);
            }
        }, Math.max(1, cfg.respawnWait) * 1000L);
    }

    /** Walks the saved route from the ramp to the chosen field. fromSpawn: reset first, then walk the ramp. */
    private void goToField(final int t, boolean fromSpawn, final Runnable then) {
        farming = false;
        final List<Patterns.Seg> route = FieldRoutes.plan(cfg.field);
        if (route.isEmpty()) { fail(t, "There is no walking route for " + cfg.field + "."); return; }
        final Runnable walk = new Runnable() {
            @Override public void run() {
                if (!running || t != token) return;
                say("Walking to " + cfg.field + ".");
                runPlan(route, false, then);
            }
        };
        if (!fromSpawn) { walk.run(); return; }
        // Reset taps are optional. If none are saved we still do the ramp walk after a short wait.
        List<int[]> resets = cfg.resetTaps();
        if (resets.isEmpty()) {
            say("No reset taps saved. Waiting then walking ramp to " + cfg.field + ".");
            handler.postDelayed(new Runnable() {
                @Override public void run() { rampWalk(t, walk); }
            }, Math.max(1500, cfg.respawnWait * 400L));
        } else {
            say("Resetting character then walking to " + cfg.field + ".");
            runTaps(resets, 0, t, new Runnable() {
                @Override public void run() { rampWalk(t, walk); }
            });
        }
    }

    /** After the camera turns, optionally walk from the reset spot to the field, then farm. */
    private void beginRun(final int t) {
        if (!cfg.walkFirst) {
            runFarm(t);
            return;
        }
        // Phase 2: quick vision check - if already on field, skip the long walk
        if (Build.VERSION.SDK_INT >= 30 && !capturePending) {
            capturePending = true;
            say("Checking if we are already on the field...");
            takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
                @Override public void onSuccess(ScreenshotResult r) {
                    capturePending = false;
                    if (!running || t != token) return;
                    HardwareBuffer hb = r.getHardwareBuffer();
                    try {
                        Bitmap hw = Bitmap.wrapHardwareBuffer(hb, r.getColorSpace());
                        if (hw != null) {
                            Bitmap sw = hw.copy(Bitmap.Config.ARGB_8888, false);
                            hw.recycle();
                            if (sw != null) {
                                int scene = AutoSense.sceneOnly(sw);
                                lastScene = scene;
                                sw.recycle();
                                if (scene == AutoSense.SCENE_ON_FIELD) {
                                    say("Vision: already on field. Starting gather.");
                                    runFarm(t);
                                    return;
                                }
                                if (scene == AutoSense.SCENE_AT_HIVE) {
                                    say("Vision: at hive. Walking to " + cfg.field + ".");
                                }
                            }
                        }
                    } catch (Exception ignored) {
                    } finally {
                        if (hb != null) hb.close();
                    }
                    goToField(t, true, farmThen(t));
                }
                @Override public void onFailure(int errorCode) {
                    capturePending = false;
                    if (!running || t != token) return;
                    goToField(t, true, farmThen(t));
                }
            });
        } else {
            goToField(t, true, farmThen(t));
        }
    }

    /** Runs the gather pattern on a loop until stopped. */
    private void runFarm(int t) {
        if (!running || t != token) return;
        converting = false;
        farming = true;
        failSafeRunning = false;
        lastBagChangeMs = SystemClock.uptimeMillis();
        lastBagSeen = bagFiltered;
        lastSelfCorrectMs = SystemClock.uptimeMillis();
        lastHiveSceneMs = 0; // fresh farm cycle - don't inherit hive scene from convert
        scheduleFailSafeCheck(t);
        say("Gathering on " + cfg.field + " (" + cfg.pattern + " " + cfg.size + ").");
        runPlan(patternPlan, true, null);
    }

    private Runnable farmThen(final int t) {
        return new Runnable() { @Override public void run() { runFarm(t); } };
    }

    // ------------------------------------------------------------ fail-safes (stuck + self-correct)

    private void scheduleFailSafeCheck(final int t) {
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (!running || t != token || !farming || converting || failSafeRunning) return;
                checkFailSafes(t);
                scheduleFailSafeCheck(t); // keep looping while farming
            }
        }, 20000); // check every 20s
    }

    private void checkFailSafes(final int t) {
        if (cfg == null) return;
        long now = SystemClock.uptimeMillis();

        // 1. Stuck: bag percent has not moved for stuckMinutes while we should be gathering
        int stuckMin = Math.max(0, cfg.stuckMinutes);
        if (stuckMin > 0 && lastBagChangeMs > 0) {
            long idleMs = now - lastBagChangeMs;
            long stuckLimit = (long) (stuckMin * 60_000L * antiDetectJitter(0.90, 1.15));
            if (idleMs > stuckLimit) {
                say("Stuck detected (bag flat ~" + stuckMin + " min). Resetting and walking back.");
                forceRealign(t, "stuck");
                return;
            }
        }

        // 2. Periodic self-correct so small drifts never stack
        int scMin = Math.max(0, cfg.selfCorrectMinutes);
        if (scMin > 0 && lastSelfCorrectMs > 0) {
            long since = now - lastSelfCorrectMs;
            long scLimit = (long) (scMin * 60_000L * antiDetectJitter(0.90, 1.15));
            if (since > scLimit) {
                say("Self-correct timer hit. Resetting position and walking back to field.");
                forceRealign(t, "self-correct");
                return;
            }
        }

        // 3. Phase 2 vision: if we are supposed to be farming but the screen looks like the hive
        //    for ~90s, we walked home by accident - realign back to the field.
        long hiveLimit = (long) (90_000L * antiDetectJitter(0.92, 1.12));
        if (lastHiveSceneMs > 0 && now - lastHiveSceneMs > hiveLimit) {
            say("Vision: still at hive while farming. Resetting and walking to field.");
            lastHiveSceneMs = 0;
            forceRealign(t, "wrong-scene");
        }
    }

    /**
     * Hard realign: stop current pattern, run reset taps, walk ramp + field route, then resume farming.
     * Used by both stuck detection and periodic self-correct.
     */
    private void forceRealign(final int t, String reason) {
        if (!running || t != token || failSafeRunning) return;
        failSafeRunning = true;
        farming = false;
        converting = false;
        handler.removeCallbacksAndMessages(null); // drop pattern steps
        token++;
        final int nt = token;
        if (inFlight) releasePending = true;
        else releaseFinger();
        lastBagChangeMs = SystemClock.uptimeMillis();
        lastSelfCorrectMs = SystemClock.uptimeMillis();
        lastHiveSceneMs = 0;
        say("Fail-safe (" + reason + "): resetting and going to " + cfg.field + ".");
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (!running || nt != token) {
                    failSafeRunning = false;
                    return;
                }
                goToField(nt, true, new Runnable() {
                    @Override public void run() {
                        failSafeRunning = false;
                        runFarm(nt);
                    }
                });
            }
        }, 700);
    }

    private void atHive(final int t) {
        if (!running || t != token) return;
        say("At hive. Sensing Make Honey button...");
        // Phase 2: live vision pass before tapping convert
        if (Build.VERSION.SDK_INT >= 30 && !capturePending) {
            capturePending = true;
            takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
                @Override public void onSuccess(ScreenshotResult r) {
                    capturePending = false;
                    int tapX = cfg.convX, tapY = cfg.convY;
                    HardwareBuffer hb = r.getHardwareBuffer();
                    try {
                        Bitmap hw = Bitmap.wrapHardwareBuffer(hb, r.getColorSpace());
                        if (hw != null) {
                            Bitmap sw = hw.copy(Bitmap.Config.ARGB_8888, false);
                            hw.recycle();
                            if (sw != null) {
                                AutoSense.Result sense = AutoSense.sense(sw, screenW(), screenH());
                                lastScene = sense.scene;
                                int[] pic = findPicture(sw, cfg.tmplConvert, cfg.convX, cfg.convY);
                                if (pic == null && cfg.tmplConvert.length() > 0) say("Make Honey picture not on screen. Using the saved spot.");
                                if (pic != null) {
                                    tapX = pic[0];
                                    tapY = pic[1];
                                    cfg.convX = tapX;
                                    cfg.convY = tapY;
                                    cfg.save();
                                    say("Found the Make Honey picture at " + tapX + "," + tapY + ".");
                                } else if (sense.convOk) {
                                    tapX = sense.convX;
                                    tapY = sense.convY;
                                    // Keep the better live spot for next time
                                    cfg.convX = tapX;
                                    cfg.convY = tapY;
                                    cfg.save();
                                    say("Vision locked Make Honey at " + tapX + "," + tapY);
                                }
                                sw.recycle();
                            }
                        }
                    } catch (Exception ignored) {
                    } finally {
                        if (hb != null) hb.close();
                    }
                    doConvertTap(t, tapX, tapY);
                }
                @Override public void onFailure(int errorCode) {
                    capturePending = false;
                    doConvertTap(t, cfg.convX, cfg.convY);
                }
            });
        } else {
            doConvertTap(t, cfg.convX, cfg.convY);
        }
    }

    /** Centre of the saved picture in a screenshot, or null if it is not on screen. */
    /** How far from the saved convert spot the first search looks, in screen pixels. */
    private static final int SEARCH_MARGIN_PX = 240;

    /**
     * Where the Make Honey picture is on the screen now, as screen coordinates of its centre, or null.
     * Looks near the saved spot first, since the button usually stays close, then over the whole screen.
     */
    private static int[] findPicture(Bitmap sw, String saved, int cx, int cy) {
        TemplateMatcher.Template tpl = TemplateMatcher.decode(saved);
        if (tpl == null) return null;
        int step = TemplateMatcher.STEP;
        int wx = Math.max(0, cx - SEARCH_MARGIN_PX), wy = Math.max(0, cy - SEARCH_MARGIN_PX);
        int wEnd = Math.min(sw.getWidth(), cx + SEARCH_MARGIN_PX), hEnd = Math.min(sw.getHeight(), cy + SEARCH_MARGIN_PX);
        int gw = (wEnd - wx) / step, gh = (hEnd - wy) / step;
        if (cx > 0 && cy > 0 && gw >= tpl.w && gh >= tpl.h) {
            TemplateMatcher.Match m = TemplateMatcher.find(readGrid(sw, wx, wy, gw, gh), gw, gh, tpl.v, tpl.w, tpl.h);
            if (m != null) return centre(wx, wy, m, tpl);
        }
        int fw = sw.getWidth() / step, fh = sw.getHeight() / step;
        TemplateMatcher.Match m = TemplateMatcher.find(readGrid(sw, 0, 0, fw, fh), fw, fh, tpl.v, tpl.w, tpl.h);
        return m == null ? null : centre(0, 0, m, tpl);
    }

    /** Screen coordinates of a match's centre, given where the grid it came from starts on the screen. */
    private static int[] centre(int x0, int y0, TemplateMatcher.Match m, TemplateMatcher.Template tpl) {
        int step = TemplateMatcher.STEP;
        return new int[]{x0 + m.x * step + tpl.w * step / 2, y0 + m.y * step + tpl.h * step / 2};
    }

    /** Says where the Make Honey picture is on the screen now, and how close the best match is. */
    private static String describePicture(Bitmap sw, String saved) {
        TemplateMatcher.Template tpl = TemplateMatcher.decode(saved);
        if (tpl == null) return "No Make Honey picture is saved yet. Save the convert spot first.";
        int step = TemplateMatcher.STEP;
        int gw = sw.getWidth() / step, gh = sw.getHeight() / step;
        TemplateMatcher.Match m = TemplateMatcher.best(readGrid(sw, 0, 0, gw, gh), gw, gh, tpl.v, tpl.w, tpl.h);
        if (m == null) return "The Make Honey picture is too plain to check. Save it again on a button with more detail.";
        if (m.score >= TemplateMatcher.MIN_SCORE) {
            int[] at = centre(0, 0, m, tpl);
            return "Make Honey picture found at " + at[0] + "," + at[1] + " (score " + fmt2(m.score) + ").";
        }
        return "Make Honey picture not found. Closest match scored " + fmt2(m.score) + ", needs " + fmt2(TemplateMatcher.MIN_SCORE) + ".";
    }

    private static String fmt2(double v) { return String.format("%.2f", v); }

    private static String pictureReport(ScreenshotResult r, String saved) {
        String out = "Could not read the screen.";
        HardwareBuffer hb = r.getHardwareBuffer();
        try {
            Bitmap hw = Bitmap.wrapHardwareBuffer(hb, r.getColorSpace());
            if (hw != null) {
                Bitmap sw = hw.copy(Bitmap.Config.ARGB_8888, false);
                hw.recycle();
                if (sw != null) {
                    out = describePicture(sw, saved);
                    sw.recycle();
                }
            }
        } catch (Exception e) {
            out = "Could not read the screen.";
        } finally {
            if (hb != null) hb.close();
        }
        return out;
    }

    /** Checks the saved Make Honey picture against the screen now, after a wait so the user can switch to Roblox. */
    public void checkConvertPicture(final long delayMs) {
        final Config c = new Config(this);
        if (c.tmplConvert.length() == 0) { say("Save the Make Honey spot first (Setup, step 4)."); return; }
        say("Checking the Make Honey picture " + (delayMs >= 1000 ? "in " + (delayMs / 1000) + " seconds" : "now")
            + ". Switch to Roblox at the hive.");
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
                    @Override public void onSuccess(ScreenshotResult r) { say(pictureReport(r, c.tmplConvert)); }
                    @Override public void onFailure(int errorCode) { say("Could not read the screen (code " + errorCode + ")."); }
                });
            }
        }, delayMs);
    }

    /** Grayscale samples taken every STEP pixels, starting at (x0, y0). */
    private static int[] readGrid(Bitmap b, int x0, int y0, int gw, int gh) {
        int[] grid = new int[gw * gh];
        for (int j = 0; j < gh; j++) {
            for (int i = 0; i < gw; i++) {
                grid[j * gw + i] = TemplateMatcher.gray(pixel(b, x0 + i * TemplateMatcher.STEP, y0 + j * TemplateMatcher.STEP));
            }
        }
        return grid;
    }

    /** Saves a picture of the 48x48 area around the Make Honey spot, once the save overlay has closed. */
    void captureConvertPicture(final int cx, final int cy) {
        takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
            @Override public void onSuccess(ScreenshotResult r) {
                int[] grid = null;
                HardwareBuffer hb = r.getHardwareBuffer();
                try {
                    Bitmap hw = Bitmap.wrapHardwareBuffer(hb, r.getColorSpace());
                    if (hw != null) {
                        Bitmap sw = hw.copy(Bitmap.Config.ARGB_8888, false);
                        hw.recycle();
                        if (sw != null) {
                            grid = readGrid(sw, cx - 24, cy - 24, 12, 12);
                            sw.recycle();
                        }
                    }
                } catch (Exception e) {
                    grid = null;
                } finally {
                    if (hb != null) hb.close();
                }
                if (grid == null) { say("Could not read the screen for the Make Honey picture."); return; }
                if (TemplateMatcher.isPlain(grid)) { say("That spot is too plain to find again. Pick a button with more detail."); return; }
                Config c = new Config(MacroAccessibilityService.this);
                c.tmplConvert = TemplateMatcher.encode(12, 12, grid);
                c.save();
                say("Make Honey picture saved.");
            }
            @Override public void onFailure(int errorCode) {
                say("Could not read the screen (code " + errorCode + ").");
            }
        });
    }

    private void doConvertTap(final int t, int x, int y) {
        if (!running || t != token) return;
        if (x > 0 && y > 0) {
            tapAt(x, y, t, new Runnable() {
                @Override public void run() { waitEmpty(t, SystemClock.uptimeMillis()); }
            });
        } else {
            say("No Make Honey spot. Waiting for bag to empty.");
            waitEmpty(t, SystemClock.uptimeMillis());
        }
    }

    private void waitEmpty(final int t, final long startMs) {
        if (!running || t != token) return;
        long el = SystemClock.uptimeMillis() - startMs;
        boolean empty = bagFiltered >= 0 && bagFiltered <= 5 && el > 5000;
        if (empty) {
            converting = false;
            final boolean back = cfg.returnToField;
            runTripsThen(t, new Runnable() {
                @Override public void run() {
                    if (back) {
                        say("Bag is empty. Walking back to " + cfg.field + ".");
                        goToField(t, false, farmThen(t));
                    } else {
                        running = false;
                        planDone = null;
                        token++;
                        releaseFinger();
                        say("Bag is empty. Stopped at the hive. Press Start to farm again.");
                    }
                }
            });
            return;
        }
        if (el > CONVERT_MAX_MS) {
            running = false;
            converting = false;
            planDone = null;
            token++;
            releaseFinger();
            say("Gave up after 5 minutes. Press Start to try again.");
            return;
        }
        handler.postDelayed(new Runnable() { @Override public void run() { waitEmpty(t, startMs); } }, 2000);
    }

    // ------------------------------------------------------------ trips from the hive

    /** Runs every trip that is due, in order, then runs then. Trips only run from the hive, after a convert. */
    private void runTripsThen(final int t, final Runnable then) { runTripFrom(t, 0, then); }

    private void runTripFrom(final int t, final int i, final Runnable then) {
        if (!running || t != token) return;
        if (i >= 2) { then.run(); return; }
        if (!tripDue(i)) { runTripFrom(t, i + 1, then); return; }
        lastTripMs[i] = SystemClock.uptimeMillis();
        runOneTrip(t, i, new Runnable() { @Override public void run() { runTripFrom(t, i + 1, then); } });
    }

    private boolean tripDue(int i) {
        if (cfg.tripMinutes[i] <= 0 || cfg.tripRoute[i].isEmpty()) return false;
        if (lastTripMs[i] < 0) return true;
        return SystemClock.uptimeMillis() - lastTripMs[i] >= cfg.tripMinutes[i] * 60000L;
    }

    /** Walks one trip's route to the building, taps its saved spots, then walks the same route back. */
    private void runOneTrip(final int t, final int i, final Runnable then) {
        final String name = cfg.tripRoute[i];
        final List<Patterns.Seg> there = TripRoutes.plan(name, cfg.hiveSlot, cfg.hiveBees);
        if (there.isEmpty()) { then.run(); return; }
        if (TripRoutes.hasTurns(there) && cfg.camX <= 0) {
            say("Set the camera spot (Setup, step 6) for trips that turn the camera.");
            then.run();
            return;
        }
        final List<Patterns.Seg> back = TripRoutes.reverse(there);
        say("Trip: " + name + ".");
        runPlan(there, false, new Runnable() {
            @Override public void run() {
                if (!running || t != token) return;
                runTaps(cfg.tripTaps(i), 0, t, new Runnable() {
                    @Override public void run() {
                        if (!running || t != token) return;
                        runPlan(back, false, then);
                    }
                });
            }
        });
    }

    /** Runs one trip now, so its route and spots can be checked from Advanced. */
    public void testTrip(final int i, final long delayMs) {
        Config c = new Config(this);
        if (c.joyX <= 0 || c.joyY <= 0) { say("Set the joystick spot first (Setup, step 2)."); return; }
        if (c.tripRoute[i].isEmpty()) { say("Pick a trip route first."); return; }
        say("Trip test " + (delayMs >= 1000 ? "starts in " + (delayMs / 1000) + " seconds" : "starts now")
            + ". Switch to Roblox now.");
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (running) { say("Stop farming before testing a trip."); return; }
                cfg = new Config(MacroAccessibilityService.this);
                running = true;
                converting = false;
                farming = false;
                token++;
                final int t = token;
                runStartMs = SystemClock.uptimeMillis();
                runOneTrip(t, i, new Runnable() {
                    @Override public void run() {
                        if (t != token) return;
                        running = false;
                        token++;
                        say("Trip test finished.");
                    }
                });
            }
        }, delayMs);
    }

    // ------------------------------------------------------------ bubble

    private GradientDrawable circle(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        g.setStroke(ui.dp(2), 0x66FFFFFF);
        return g;
    }

    public void showBubble() {
        if (bubbleShown || wm == null || ui == null) return;
        final int d = ui.dp(62);

        bubble = new Button(this);
        bubble.setAllCaps(false);
        bubble.setTextSize(13);
        bubble.setTextColor(0xFFFFFFFF);
        bubble.setMinWidth(0);
        bubble.setMinimumWidth(0);
        bubble.setMinHeight(0);
        bubble.setMinimumHeight(0);
        bubble.setPadding(0, 0, 0, 0);
        bubble.setOnTouchListener(new View.OnTouchListener() {
            private float downX, downY;
            private int startX, startY;
            private boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startX = rootLp.x;
                        startY = rootLp.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downX;
                        float dy = e.getRawY() - downY;
                        if (Math.abs(dx) > ui.dp(6) || Math.abs(dy) > ui.dp(6)) moved = true;
                        if (moved) moveRoot(startX + (int) dx, startY + (int) dy);
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) toggleCard();
                        return true;
                    default:
                        return false;
                }
            }
        });

        card = ui.card();
        card.setMinimumWidth(ui.dp(250));
        cardStatus = ui.text("", Ui.TEXT, 16, true);
        cardBag = ui.body("");
        cardToggle = ui.primary("Start", Ui.GREEN);
        cardToggle.setOnClickListener(v -> {
            if (running) stopMacro(); else startMacro();
            updateCard();
        });
        Button open = ui.secondary("Open app");
        open.setOnClickListener(v -> startActivity(new Intent(this, MainActivity.class)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)));
        Button hide = ui.secondary("Hide bubble");
        hide.setOnClickListener(v -> hideBubble());
        card.addView(cardStatus, ui.full(4));
        card.addView(cardBag, ui.full(10));
        card.addView(cardToggle, ui.full(8));
        card.addView(open, ui.full(8));
        card.addView(hide, ui.full(0));
        card.setVisibility(View.GONE);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.addView(bubble, new LinearLayout.LayoutParams(d, d));
        root.addView(card, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        rootLp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        rootLp.gravity = Gravity.TOP | Gravity.START;
        rootLp.x = ui.dp(6);
        rootLp.y = ui.dp(140);
        wm.addView(root, rootLp);
        bubbleShown = true;
        updateCard();
        if (running || expanded) startPolling();
    }

    public void hideBubble() {
        if (root != null && wm != null && bubbleShown) {
            try { wm.removeView(root); } catch (Exception ignored) {}
        }
        bubbleShown = false;
        expanded = false;
        root = null;
        bubble = null;
        card = null;
        cardStatus = null;
        cardBag = null;
        cardToggle = null;
    }

    private void moveRoot(int x, int y) {
        if (root == null || wm == null) return;
        int sw = screenW(), sh = screenH();
        rootLp.x = Math.max(0, Math.min(sw - ui.dp(70), x));
        rootLp.y = Math.max(0, Math.min(sh - ui.dp(330), y)); // keep the menu card on screen
        wm.updateViewLayout(root, rootLp);
    }

    private void toggleCard() {
        if (card == null) return;
        expanded = !expanded;
        card.setVisibility(expanded ? View.VISIBLE : View.GONE);
        if (expanded) startPolling();
        updateCard();
    }

    private void updateCard() {
        if (bubble == null) return;
        bubble.setText(running ? "STOP" : "GO");
        bubble.setBackground(circle(running ? Ui.RED : Ui.GREEN));
        cardStatus.setText(status);
        cardBag.setText(bagLine);
        cardToggle.setText(running ? "Stop" : "Start");
        cardToggle.setBackground(ui.box(running ? Ui.RED : Ui.GREEN, 14));
    }

    // ------------------------------------------------------------ tap-to-save overlay

    /**
     * Dims the screen, shows an instruction card, and puts a ring where the user taps.
     * Nothing is saved until "Save here", so a mis-tap is harmless.
     */
    public void guidePoint(final String instruction, final String label) {
        if (calibView != null || wm == null || ui == null) return;
        if (root != null) root.setVisibility(View.GONE);
        final int ring = ui.dp(44);
        final FrameLayout f = new FrameLayout(this);
        f.setBackgroundColor(0x55000000);

        final View marker = new View(this);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setStroke(ui.dp(3), Ui.AMBER);
        g.setColor(0x33F5A524);
        marker.setBackground(g);
        marker.setVisibility(View.GONE);
        f.addView(marker, new FrameLayout.LayoutParams(ring, ring));

        LinearLayout panel = ui.card();
        panel.setClickable(true);
        panel.addView(ui.text(instruction, Ui.TEXT, 18, false), ui.full(14));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button save = ui.primary("Save here", Ui.GREEN);
        Button cancel = ui.secondary("Cancel");
        LinearLayout.LayoutParams lpSave = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lpSave.setMargins(0, 0, ui.dp(6), 0);
        LinearLayout.LayoutParams lpCancel = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lpCancel.setMargins(ui.dp(6), 0, 0, 0);
        row.addView(save, lpSave);
        row.addView(cancel, lpCancel);
        panel.addView(row, ui.full(0));
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP);
        cp.setMargins(ui.dp(16), ui.dp(56), ui.dp(16), 0);
        f.addView(panel, cp);

        final float[] pt = {-1f, -1f};
        f.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_MOVE || a == MotionEvent.ACTION_UP) {
                    pt[0] = e.getRawX();
                    pt[1] = e.getRawY();
                    marker.setVisibility(View.VISIBLE);
                    marker.setTranslationX(pt[0] - ring / 2f);
                    marker.setTranslationY(pt[1] - ring / 2f);
                    return true;
                }
                return false;
            }
        });
        save.setOnClickListener(v -> {
            if (pt[0] < 0) {
                Toast.makeText(this, "Tap the spot on the screen first.", Toast.LENGTH_SHORT).show();
                return;
            }
            int x = Math.round(pt[0]), y = Math.round(pt[1]);
            closeCalib();
            savePoint(label, x, y);
        });
        cancel.setOnClickListener(v -> {
            closeCalib();
            say("Cancelled. Nothing was changed.");
        });

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        wm.addView(f, lp);
        calibView = f;
    }

    private void closeCalib() {
        if (calibView != null && wm != null) {
            try { wm.removeView(calibView); } catch (Exception ignored) {}
        }
        calibView = null;
        if (root != null) root.setVisibility(View.VISIBLE);
    }

    void savePoint(String label, int x, int y) {
        Config c = new Config(this);
        String what;
        if ("joy".equals(label)) { c.joyX = x; c.joyY = y; what = "Joystick spot saved."; }
        else if ("cam".equals(label)) { c.camX = x; c.camY = y; what = "Camera spot saved."; }
        else if ("bag".equals(label)) { c.bagX = x; c.bagY = y; what = "Bag spot saved. Open the bubble to see the reading."; }
        else if ("conv".equals(label)) { c.convX = x; c.convY = y; what = "Make Honey button saved."; }
        else if ("dc".equals(label)) { c.dcX = x; c.dcY = y; what = "Disconnect spot saved. Reading its color..."; }
        else if ("item".equals(label)) { c.addItemTap(x, y); what = "Item tap " + c.itemTaps().size() + " saved."; }
        else if ("booster".equals(label)) { c.addBoosterTap(x, y); what = "Booster tap " + c.boosterTaps().size() + " saved."; }
        else if ("planter".equals(label)) { c.addPlanterTap(x, y); what = "Planter tap " + c.planterTaps().size() + " saved."; }
        else if ("quest".equals(label)) { c.addQuestTap(x, y); what = "Turn-in tap " + c.questTaps().size() + " saved."; }
        else if ("questnpc".equals(label)) { c.addQuestNpcTap(x, y); what = "NPC next-quest tap " + c.questNpcTaps().size() + " saved."; }
        else if ("trip0".equals(label) || "trip1".equals(label)) {
            int idx = "trip1".equals(label) ? 1 : 0;
            c.addTripTap(idx, x, y);
            what = "Trip " + (idx + 1) + " tap " + c.tripTaps(idx).size() + " saved.";
        }
        else { c.addResetTap(x, y); what = "Reset step " + c.resetTaps().size() + " saved."; }
        c.save();
        say(what);
        if ("conv".equals(label)) {
            handler.postDelayed(new Runnable() { @Override public void run() { captureConvertPicture(x, y); } }, 700);
        }
        if ("dc".equals(label)) {
            handler.postDelayed(new Runnable() { @Override public void run() { sampleDisconnectColor(); } }, 700);
        }
    }
}

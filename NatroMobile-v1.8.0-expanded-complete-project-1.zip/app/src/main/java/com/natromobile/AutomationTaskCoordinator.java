package com.natromobile;

/**
 * Deterministic priority arbiter shared by automation subsystems.
 * This class chooses work; it does not execute Android gestures itself.
 */
public final class AutomationTaskCoordinator {
    public enum Task {
        NONE(0), FARMING(10), QUEST(20), CONVERSION(30), RECOVERY(40),
        ACCESSIBILITY_LOST(90), USER_INTERRUPTION(95), EMERGENCY_STOP(100);
        public final int priority;
        Task(int priority) { this.priority = priority; }
    }

    public static final class Pending {
        public boolean farming, quest, conversion, recovery, accessibilityLost, userInterruption;
    }

    private boolean emergencyLatched;

    public synchronized void emergencyStop() { emergencyLatched = true; }
    public synchronized void resetEmergencyStop() { emergencyLatched = false; }
    public synchronized boolean isEmergencyLatched() { return emergencyLatched; }

    public synchronized Task choose(Pending p) {
        if (emergencyLatched) return Task.EMERGENCY_STOP;
        if (p == null) return Task.NONE;
        if (p.userInterruption) return Task.USER_INTERRUPTION;
        if (p.accessibilityLost) return Task.ACCESSIBILITY_LOST;
        if (p.recovery) return Task.RECOVERY;
        if (p.conversion) return Task.CONVERSION;
        if (p.quest) return Task.QUEST;
        if (p.farming) return Task.FARMING;
        return Task.NONE;
    }

    /** True only when the candidate is allowed to begin at this decision boundary. */
    public synchronized boolean mayStart(Task candidate, Pending pending) {
        return candidate != null && candidate != Task.NONE && choose(pending) == candidate;
    }
}

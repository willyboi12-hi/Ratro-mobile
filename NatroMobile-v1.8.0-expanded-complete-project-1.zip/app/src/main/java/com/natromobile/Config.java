package com.natromobile;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;

/** Saved settings (SharedPreferences). Coordinates are screen pixels in the orientation Roblox is played in. */
public final class Config {
    public static final String[] FULL_ACTIONS = {"Keep going", "Stop", "Convert at hive"};

    private final SharedPreferences p;
    public int joyX, joyY, camX, camY, radius, swipeLen, rotateSwipes, reps, runMinutes;
    public int bagX, bagY, convX, convY, fullAction, fullPercent, hiveSlot, respawnWait, itemMinutes;
    public int boosterMinutes, planterMinutes, questMinutes; // phase 4 intervals
    public int dcX, dcY, dcColor, rejoinSec;
    public int stuckMinutes, selfCorrectMinutes; // fail-safe timers
    public float moveSpeed;
    public String pattern, size, resetSteps, itemSteps, field, privateLink;
    public int hiveBees;
    public String tmplConvert = "";   // saved picture of the Make Honey button (TemplateMatcher text form)
    public final String[] tripRoute = {"", ""};
    public final int[] tripMinutes = {0, 0};
    public final String[] tripSteps = {"", ""};
    public String boosterSteps, planterSteps, questSteps, questNpcSteps; // phase 4 + next-quest NPC
    public boolean invFB, invLR, facingCorner, walkFirst, returnToField, watchRoblox, questSmart, humanMode;
    public int humanLevel; // 0 light, 1 normal, 2 heavy

    public Config(Context c) {
        p = c.getSharedPreferences("natro_mobile", Context.MODE_PRIVATE);
        load();
    }

    public void load() {
        joyX = p.getInt("joyX", 0);
        joyY = p.getInt("joyY", 0);
        camX = p.getInt("camX", 0);
        camY = p.getInt("camY", 0);
        radius = p.getInt("radius", 110);
        swipeLen = p.getInt("swipeLen", 300);
        rotateSwipes = p.getInt("rotateSwipes", 0);
        reps = p.getInt("reps", 1);
        runMinutes = p.getInt("runMinutes", 0);
        moveSpeed = p.getFloat("moveSpeed", 48f);
        pattern = p.getString("pattern", "Snake");
        size = p.getString("size", "M");
        invFB = p.getBoolean("invFB", false);
        invLR = p.getBoolean("invLR", false);
        facingCorner = p.getBoolean("facingCorner", false);
        bagX = p.getInt("bagX", 0);
        bagY = p.getInt("bagY", 0);
        convX = p.getInt("convX", 0);
        convY = p.getInt("convY", 0);
        fullAction = p.getInt("fullAction", 2); // default Convert at hive for auto loop
        fullPercent = p.getInt("fullPercent", 95);
        hiveSlot = p.getInt("hiveSlot", 1);
        respawnWait = p.getInt("respawnWait", 6);
        resetSteps = p.getString("resetSteps", "");
        itemMinutes = p.getInt("itemMinutes", 0);
        itemSteps = p.getString("itemSteps", "");
        hiveBees = p.getInt("hiveBees", 50);
        tmplConvert = p.getString("tmplConvert", "");
        for (int i = 0; i < 2; i++) {
            tripRoute[i] = p.getString("tripRoute" + i, "");
            tripMinutes[i] = p.getInt("tripMinutes" + i, 0);
            tripSteps[i] = p.getString("tripSteps" + i, "");
        }
        boosterMinutes = p.getInt("boosterMinutes", 0);
        boosterSteps = p.getString("boosterSteps", "");
        planterMinutes = p.getInt("planterMinutes", 0);
        planterSteps = p.getString("planterSteps", "");
        questMinutes = p.getInt("questMinutes", 0);
        questSteps = p.getString("questSteps", "");
        questNpcSteps = p.getString("questNpcSteps", "");
        field = p.getString("field", "Pine Tree");
        walkFirst = p.getBoolean("walkFirst", true);
        returnToField = p.getBoolean("returnToField", true);
        dcX = p.getInt("dcX", 0);
        dcY = p.getInt("dcY", 0);
        dcColor = p.getInt("dcColor", 0);
        privateLink = p.getString("privateLink", "");
        rejoinSec = p.getInt("rejoinSec", 60);
        watchRoblox = p.getBoolean("watchRoblox", true);
        questSmart = p.getBoolean("questSmart", true);
        humanMode = p.getBoolean("humanMode", true);
        humanLevel = p.getInt("humanLevel", 1);
        stuckMinutes = p.getInt("stuckMinutes", 4);
        selfCorrectMinutes = p.getInt("selfCorrectMinutes", 12);
    }

    public void save() {
        saveTrips();
        p.edit()
            .putInt("joyX", joyX).putInt("joyY", joyY)
            .putInt("camX", camX).putInt("camY", camY)
            .putInt("radius", radius).putInt("swipeLen", swipeLen)
            .putInt("rotateSwipes", rotateSwipes).putInt("reps", reps)
            .putInt("runMinutes", runMinutes)
            .putFloat("moveSpeed", moveSpeed)
            .putString("pattern", pattern).putString("size", size)
            .putBoolean("invFB", invFB).putBoolean("invLR", invLR)
            .putBoolean("facingCorner", facingCorner)
            .putInt("bagX", bagX).putInt("bagY", bagY)
            .putInt("convX", convX).putInt("convY", convY)
            .putInt("fullAction", fullAction).putInt("fullPercent", fullPercent)
            .putInt("hiveSlot", hiveSlot).putInt("respawnWait", respawnWait)
            .putString("resetSteps", resetSteps)
            .putInt("itemMinutes", itemMinutes).putString("itemSteps", itemSteps)
            .putInt("boosterMinutes", boosterMinutes).putString("boosterSteps", boosterSteps)
            .putInt("planterMinutes", planterMinutes).putString("planterSteps", planterSteps)
            .putInt("questMinutes", questMinutes).putString("questSteps", questSteps)
            .putString("questNpcSteps", questNpcSteps)
            .putString("field", field)
            .putBoolean("walkFirst", walkFirst).putBoolean("returnToField", returnToField)
            .putInt("dcX", dcX).putInt("dcY", dcY).putInt("dcColor", dcColor)
            .putString("privateLink", privateLink).putInt("rejoinSec", rejoinSec)
            .putBoolean("watchRoblox", watchRoblox)
            .putBoolean("questSmart", questSmart)
            .putBoolean("humanMode", humanMode)
            .putInt("humanLevel", humanLevel)
            .putInt("stuckMinutes", stuckMinutes)
            .putInt("selfCorrectMinutes", selfCorrectMinutes)
            .apply();
    }

    /** Saved taps are stored as "x,y;x,y;...". */
    public static List<int[]> parseTaps(String s) {
        List<int[]> out = new ArrayList<int[]>();
        if (s == null || s.length() == 0) return out;
        for (String part : s.split(";")) {
            String[] xy = part.split(",");
            if (xy.length != 2) continue;
            try { out.add(new int[]{Integer.parseInt(xy[0].trim()), Integer.parseInt(xy[1].trim())}); }
            catch (NumberFormatException ignored) {}
        }
        return out;
    }

    private static String appendTap(String cur, int x, int y) {
        return (cur == null || cur.length() == 0) ? x + "," + y : cur + ";" + x + "," + y;
    }

    public List<int[]> resetTaps() { return parseTaps(resetSteps); }
    public List<int[]> itemTaps() { return parseTaps(itemSteps); }
    public List<int[]> boosterTaps() { return parseTaps(boosterSteps); }
    public List<int[]> planterTaps() { return parseTaps(planterSteps); }
    public List<int[]> questTaps() { return parseTaps(questSteps); }
    public List<int[]> questNpcTaps() { return parseTaps(questNpcSteps); }
    public void addResetTap(int x, int y) { resetSteps = appendTap(resetSteps, x, y); }
    public void addItemTap(int x, int y) { itemSteps = appendTap(itemSteps, x, y); }
    private void saveTrips() {
        SharedPreferences.Editor e = p.edit();
        for (int i = 0; i < 2; i++) {
            e.putString("tripRoute" + i, tripRoute[i]).putInt("tripMinutes" + i, tripMinutes[i])
                .putString("tripSteps" + i, tripSteps[i]);
        }
        e.putInt("hiveBees", hiveBees);
        e.putString("tmplConvert", tmplConvert);
        e.apply();
    }
    public List<int[]> tripTaps(int i) { return parseTaps(tripSteps[i]); }
    public void addTripTap(int i, int x, int y) { tripSteps[i] = appendTap(tripSteps[i], x, y); }
    public void addBoosterTap(int x, int y) { boosterSteps = appendTap(boosterSteps, x, y); }
    public void addPlanterTap(int x, int y) { planterSteps = appendTap(planterSteps, x, y); }
    public void addQuestTap(int x, int y) { questSteps = appendTap(questSteps, x, y); }
    public void addQuestNpcTap(int x, int y) { questNpcSteps = appendTap(questNpcSteps, x, y); }

    /**
     * Fills missing spots with ratio-based guesses for typical Roblox mobile layouts.
     * Call once with the real screen size after the service starts. Only writes zeros.
     * These are starting points - user can still re-set any that land off.
     */
    public boolean applySmartDefaults(int screenW, int screenH) {
        boolean changed = false;
        if (screenW < 200 || screenH < 200) return false;

        // Joystick: bottom-left area on most phones (Roblox virtual stick)
        if (joyX <= 0 || joyY <= 0) {
            joyX = Math.max(40, (int) (screenW * 0.17f));
            joyY = Math.max(40, (int) (screenH * 0.78f));
            changed = true;
        }
        // Bag left end of pollen bar (top area)
        if (bagX <= 0 || bagY <= 0) {
            bagX = Math.max(20, (int) (screenW * 0.11f));
            bagY = Math.max(20, (int) (screenH * 0.07f));
            changed = true;
        }
        // Make Honey / convert button is more variable; put a mid-right guess
        if (convX <= 0 || convY <= 0) {
            convX = Math.max(40, (int) (screenW * 0.72f));
            convY = Math.max(40, (int) (screenH * 0.55f));
            changed = true;
        }
        // Reasonable radius for stick travel
        if (radius < 60) {
            radius = Math.min(160, Math.max(90, (int) (screenW * 0.12f)));
            changed = true;
        }
        if (changed) save();
        return changed;
    }
}

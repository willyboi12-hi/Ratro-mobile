package com.natromobile;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Turns a Roblox game link into a roblox:// link. Android opens roblox:// links straight in the Roblox app,
 * so it does not need to ask which app to use, the way it can for a web link.
 */
public final class RobloxLink {
    private static final Pattern GAME = Pattern.compile("roblox\\.com/games/(\\d+)");
    private static final Pattern CODE = Pattern.compile("[?&]privateServerLinkCode=([^&#]+)");

    private RobloxLink() {}

    /** Returns a roblox:// link when the input is a game link with a private server code. Anything else comes back unchanged. */
    public static String toRobloxUri(String link) {
        if (link == null) return "";
        String s = link.trim();
        if (s.startsWith("roblox://")) return s;
        Matcher game = GAME.matcher(s);
        Matcher code = CODE.matcher(s);
        if (game.find() && code.find()) {
            return "roblox://placeID=" + game.group(1) + "&linkCode=" + code.group(1);
        }
        return s;
    }
}

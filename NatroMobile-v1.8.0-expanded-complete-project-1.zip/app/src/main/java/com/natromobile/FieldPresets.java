package com.natromobile;

/**
 * Phase 3: per-field gather presets (pattern, size, camera turns, corner flag).
 * Tuned for mobile Natro-style routes. Not gospel - user can still override.
 */
public final class FieldPresets {
    private FieldPresets() {}

    public static final class Preset {
        public final String pattern;
        public final String size;
        public final int rotateSwipes; // camera turns before start
        public final boolean facingCorner;
        public final String note;

        public Preset(String pattern, String size, int rotateSwipes, boolean facingCorner, String note) {
            this.pattern = pattern;
            this.size = size;
            this.rotateSwipes = rotateSwipes;
            this.facingCorner = facingCorner;
            this.note = note;
        }
    }

    /** Returns a sensible default preset for the field name, or a generic Snake M if unknown. */
    public static Preset forField(String name) {
        if (name == null) return generic();
        switch (name) {
            case "Bamboo":
                return new Preset("Snake", "M", 0, false, "Long rows work well on Bamboo.");
            case "Blue Flower":
                return new Preset("Snake", "S", 0, false, "Smaller snake keeps you in the blue flowers.");
            case "Cactus":
                return new Preset("Lines", "M", 0, false, "Straight lines across cactus rows.");
            case "Clover":
                return new Preset("Snake", "M", 0, false, "Classic clover snake.");
            case "Coconut":
                return new Preset("Snake", "L", 1, false, "Big field; route may drift from jumps.");
            case "Dandelion":
                return new Preset("Snake", "S", 0, false, "Tight dandelion patch.");
            case "Mountain Top":
                return new Preset("XSnake", "M", 0, false, "XSnake covers the wide mountain top.");
            case "Mushroom":
                return new Preset("Snake", "S", 0, false, "Compact mushroom field.");
            case "Pepper":
                return new Preset("Snake", "M", 1, false, "Pepper route has jumps - expect drift.");
            case "Pineapple":
                return new Preset("Lines", "M", 0, false, "Lines across pineapple.");
            case "Pine Tree":
                return new Preset("Snake", "L", 0, false, "Default pine - large snake.");
            case "Pumpkin":
                return new Preset("Squares", "M", 0, false, "Squares around pumpkin center.");
            case "Rose":
                return new Preset("Snake", "M", 0, false, "Rose snake.");
            case "Spider":
                return new Preset("Diamonds", "M", 0, false, "Diamonds for spider field.");
            case "Strawberry":
                return new Preset("Snake", "S", 0, false, "Tight strawberry rows.");
            case "Stump":
                return new Preset("Fork", "M", 0, true, "Fork facing corner near stump.");
            case "Sunflower":
                return new Preset("Snake", "M", 0, false, "Sunflower snake.");
            default:
                return generic();
        }
    }

    private static Preset generic() {
        return new Preset("Snake", "M", 0, false, "Generic field preset.");
    }

    /** Apply preset onto a Config and save. */
    public static void apply(Config c, String fieldName) {
        Preset p = forField(fieldName);
        c.field = fieldName;
        c.pattern = p.pattern;
        c.size = p.size;
        c.rotateSwipes = p.rotateSwipes;
        c.facingCorner = p.facingCorner;
        c.save();
    }
}

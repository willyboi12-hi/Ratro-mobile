# Contributing

1. Keep changes focused and preserve existing behavior.
2. Run `bash tests/run.sh` before submitting.
3. Add regression tests for bug fixes and behavior changes.
4. Do not claim tests or builds ran unless they did.
5. Keep Android-only behavior behind Android APIs and use deterministic test doubles for JVM tests.
6. Do not add hidden game-state access, injection, memory manipulation, or network tampering.
7. Update documentation when changing settings, task behavior, or build requirements.
8. Do not commit generated build output, secrets, or signing keys.

The source contains GPL-licensed material; read `NATRO_SOURCE_LICENSE.md` before redistribution.

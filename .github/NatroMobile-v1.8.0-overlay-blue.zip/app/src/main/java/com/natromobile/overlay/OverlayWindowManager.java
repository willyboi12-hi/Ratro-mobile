package com.natromobile.overlay;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.WindowManager;

import com.natromobile.Ui;

/**
 * Owns the floating bubble and dashboard windows.
 * Uses TYPE_ACCESSIBILITY_OVERLAY when available (from AccessibilityService context).
 */
public class OverlayWindowManager {

    private final Context context;
    private final Ui ui;
    private final OverlaySettings settings;
    private final OverlayMacroController macro;
    private final WindowManager wm;

    private OverlayBubbleView bubble;
    private OverlayDashboardView dashboard;
    private WindowManager.LayoutParams bubbleLp;
    private WindowManager.LayoutParams dashLp;
    private boolean bubbleShown;
    private boolean dashboardShown;

    public OverlayWindowManager(Context c) {
        this.context = c.getApplicationContext();
        this.ui = new Ui(c);
        this.settings = new OverlaySettings(c);
        this.macro = new OverlayMacroController();
        this.wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
    }

    public void showBubble() {
        if (bubbleShown || wm == null) return;
        int size = ui.dp(settings.getBubbleSizeDp());

        bubbleLp = new WindowManager.LayoutParams(
            size, size,
            windowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        );
        bubbleLp.gravity = Gravity.TOP | Gravity.START;

        int bx = settings.getBubbleX();
        int by = settings.getBubbleY();
        if (bx < 0 || by < 0) {
            bubbleLp.x = ui.dp(12);
            bubbleLp.y = ui.dp(180);
        } else {
            bubbleLp.x = bx;
            bubbleLp.y = by;
        }

        bubble = new OverlayBubbleView(context, ui, settings, macro);
        bubble.setLayoutParams(bubbleLp);
        bubble.setListener(new OverlayBubbleView.Listener() {
            @Override public void onTap() { toggleDashboard(); }
            @Override public void onDragEnd(int x, int y) { /* saved inside view */ }
        });

        try {
            wm.addView(bubble, bubbleLp);
            bubbleShown = true;
            bubble.refreshStatus();
        } catch (Exception e) {
            bubbleShown = false;
            bubble = null;
        }
    }

    public void hideBubble() {
        if (bubble != null && bubbleShown && wm != null) {
            try { wm.removeView(bubble); } catch (Exception ignored) {}
        }
        bubbleShown = false;
        bubble = null;
        hideDashboard();
    }

    public void toggleDashboard() {
        if (dashboardShown) hideDashboard();
        else showDashboard();
    }

    public void showDashboard() {
        if (dashboardShown || wm == null) return;
        int width = ui.dp(340);

        dashLp = new WindowManager.LayoutParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT,
            windowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        );
        dashLp.gravity = Gravity.TOP | Gravity.START;

        int px = settings.getPanelX();
        int py = settings.getPanelY();
        if (px < 0 || py < 0) {
            dashLp.x = ui.dp(16);
            dashLp.y = ui.dp(100);
        } else {
            dashLp.x = px;
            dashLp.y = py;
        }

        dashboard = new OverlayDashboardView(context, ui, settings, macro);
        dashboard.setLayoutParams(dashLp);
        dashboard.setListener(new OverlayDashboardView.Listener() {
            @Override public void onMinimize() { hideDashboard(); }
            @Override public void onClose() { hideDashboard(); hideBubble(); }
            @Override public void onDragEnd(int x, int y) { /* saved inside view */ }
        });

        try {
            wm.addView(dashboard, dashLp);
            dashboardShown = true;
            if (bubble != null) bubble.setVisibility(android.view.View.GONE);
        } catch (Exception e) {
            dashboardShown = false;
            dashboard = null;
        }
    }

    public void hideDashboard() {
        if (dashboard != null && dashboardShown && wm != null) {
            dashboard.stopTicker();
            try { wm.removeView(dashboard); } catch (Exception ignored) {}
        }
        dashboardShown = false;
        dashboard = null;
        if (bubble != null) {
            bubble.setVisibility(android.view.View.VISIBLE);
            bubble.refreshStatus();
        }
    }

    public void refreshStatus() {
        if (bubble != null) bubble.refreshStatus();
        if (dashboard != null) dashboard.refresh();
    }

    public boolean isBubbleShown() { return bubbleShown; }
    public boolean isDashboardShown() { return dashboardShown; }

    private int windowType() {
        // Prefer accessibility overlay when running inside AccessibilityService
        if (Build.VERSION.SDK_INT >= 22) {
            try {
                return WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY;
            } catch (Throwable t) { /* fall through */ }
        }
        if (Build.VERSION.SDK_INT >= 26) {
            return WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        }
        return WindowManager.LayoutParams.TYPE_PHONE;
    }

    public void destroy() {
        hideDashboard();
        hideBubble();
    }
}

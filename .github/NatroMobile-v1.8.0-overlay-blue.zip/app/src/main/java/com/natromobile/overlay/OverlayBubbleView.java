package com.natromobile.overlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.natromobile.Ui;

/**
 * Small draggable floating Natro icon with status ring.
 * Blue neon hex N style matching the reference icon.
 */
public class OverlayBubbleView extends FrameLayout {

    public interface Listener {
        void onTap();
        void onDragEnd(int x, int y);
    }

    private final Ui ui;
    private final OverlaySettings settings;
    private final OverlayMacroController macro;
    private Listener listener;
    private WindowManager.LayoutParams lp;
    private TextView icon;
    private View statusDot;
    private float downRawX, downRawY;
    private int startX, startY;
    private boolean moved;
    private long lastTapMs;

    public OverlayBubbleView(Context c, Ui ui, OverlaySettings settings, OverlayMacroController macro) {
        super(c);
        this.ui = ui;
        this.settings = settings;
        this.macro = macro;
        build();
    }

    public void setListener(Listener l) { this.listener = l; }
    public void setLayoutParams(WindowManager.LayoutParams params) { this.lp = params; }

    private void build() {
        int size = ui.dp(settings.getBubbleSizeDp());
        setLayoutParams(new LayoutParams(size, size));

        // Dark rounded square with strong blue neon border matching reference icon
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(ui.dp(16));
        bg.setColor(0xF00A0C10);
        bg.setStroke(ui.dp(2.5f), Ui.BLUE_LIGHT);
        setBackground(bg);
        setElevation(ui.dp(12));

        // Bright N icon
        icon = new TextView(getContext());
        icon.setText("N");
        icon.setTextColor(0xFFFFFFFF);
        icon.setTextSize(24);
        icon.setTypeface(Typeface.DEFAULT_BOLD);
        icon.setGravity(Gravity.CENTER);
        addView(icon, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        // Status dot top-right
        statusDot = new View(getContext());
        GradientDrawable dot = new GradientDrawable();
        dot.setShape(GradientDrawable.OVAL);
        dot.setColor(0xFF6B7280); // gray default
        statusDot.setBackground(dot);
        LayoutParams dlp = new LayoutParams(ui.dp(12), ui.dp(12));
        dlp.gravity = Gravity.TOP | Gravity.END;
        dlp.setMargins(0, ui.dp(4), ui.dp(4), 0);
        addView(statusDot, dlp);

        setOnTouchListener(this::onTouch);
        refreshStatus();
    }

    public void refreshStatus() {
        int color;
        if (!macro.isConnected()) {
            color = 0xFF6B7280; // gray
        } else if (macro.isRunning()) {
            color = Ui.BLUE_LIGHT; // blue = running
        } else {
            color = 0xFF6B7280;
        }
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        statusDot.setBackground(d);
    }

    private boolean onTouch(View v, MotionEvent e) {
        if (lp == null) return false;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downRawX = e.getRawX();
                downRawY = e.getRawY();
                startX = lp.x;
                startY = lp.y;
                moved = false;
                return true;
            case MotionEvent.ACTION_MOVE:
                float dx = e.getRawX() - downRawX;
                float dy = e.getRawY() - downRawY;
                if (Math.abs(dx) > ui.dp(6) || Math.abs(dy) > ui.dp(6)) moved = true;
                if (moved) {
                    lp.x = startX + (int) dx;
                    lp.y = startY + (int) dy;
                    try {
                        WindowManager wm = (WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
                        if (wm != null) wm.updateViewLayout(this, lp);
                    } catch (Exception ignored) {}
                }
                return true;
            case MotionEvent.ACTION_UP:
                if (moved) {
                    settings.setBubblePos(lp.x, lp.y);
                    if (listener != null) listener.onDragEnd(lp.x, lp.y);
                } else {
                    long now = System.currentTimeMillis();
                    if (now - lastTapMs > 300) {
                        lastTapMs = now;
                        if (listener != null) listener.onTap();
                    }
                }
                return true;
            default:
                return false;
        }
    }
}
